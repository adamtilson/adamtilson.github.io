# frozen_string_literal: true

require "jekyll"

collapse_all = '<button class="expandall">Collapse All</button>'
start_collapsy_button = '<section id="'
continue_collapsy_button = '"><button class="collapsible">'
end_collapsy_button = '</button><div class="text-content"><div markdown="1" class="text-inner">'
end_collapsy = '</div></div></section>'
code_button = '<div class="code-header"><button class="copy-code-button" aria-label="Copy code to clipboard"></button></div>'


Jekyll::Hooks.register([:pages], :pre_render) do |post|
    def create_name(inName)
        return inName.downcase.gsub(/[^0-9A-Za-z]/, '')
    end
    post.content.sub!(/^## (.*)$/) { collapse_all+"\n"+start_collapsy_button+create_name($1)+continue_collapsy_button+$1+end_collapsy_button }
    post.content.gsub!(/^## (.*)$/) { end_collapsy+start_collapsy_button+create_name($1)+continue_collapsy_button+$1+end_collapsy_button }
    # post.content.gsub!(/\n\n^```(.*)$/){ "\n\n"+code_button+"\n```"+$1 } # should work based on what I know, but isn't. will defer to javascript!
end

Jekyll::Hooks.register([:pages], :post_convert) do |post|
    post.content.sub!(/^(<button> (.|\n)*)\z/, '\1'+end_collapsy)
end