---
layout: default
---

# ENSE 411 - Artificial Intelligence - Laboratory

University of Regina - Engineering and Applied Science - Software Systems Engineering

Lab Instructor: [Adam Tilson](mailto:Adam.Tilson@uregina.ca)

---

## Schedule

Labs will be on Friday's  and delivered remotely over Zoom. Zoom details will be posted on URCourses.

| Title                    | Assigned | Due | Grading |
|--------------------------| :-------:| :--:| :------:|
|0. Unix / Python Tutorial | Sept 17  | Sept 24 | 2%|
|1. Search                 | Sept 24  | Oct 8  | 4%|
|2. Multi-Agent Search     | Oct 8    | Oct 22 |5%|
|3. Reinforcement Learning | Oct 22   | Nov 5  | 5%|
|4. Ghostbusters           | Nov 5    | Nov 26 | 5%|
|5. Machine Learning       | Nov 19   | Dec 3  |4%|
|Total Lab Grade:          |          |        |  25%|
