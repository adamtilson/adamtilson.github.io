---
layout: default
---

# ENSE 472 - Digital Networks - Laboratory

University of Regina - Engineering and Applied Science - Software Systems Engineering

Lab Instructor: [Adam Tilson](mailto:Adam.Tilson@uregina.ca)

---

## Schedule

Labs will be on Friday's  and delivered remotely over Zoom. Zoom details will be posted on URCourses.

| Title                            | Assigned | Due | Grading |
|----------------------------------| :-------:| :--:| :------:|
|1. Intro to Packet Tracer         | Sept 27  | Oct 4  |3%|
|2. Packet Tracer Business Network | Oct 4    | Oct 18 |3%|
|3. OMNeT++/INET Topologies        | Oct 18   | Nov 1  |3%|
|4. OMNeT++/INET RIP               | Nov 1    | Nov 15 |3%|
|5. OMNeT++/INET Quality of Service| Nov 15   | Nov 29 |3%|
|Total Lab Grade:                  |          |        |15%|
