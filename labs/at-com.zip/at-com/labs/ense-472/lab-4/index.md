---
layout: default
title: ENSE 472 Lab 4
---
# Lab 4: Network Application Programming - Godot Multiplayer

ENSE 472 - Digital Networks - Laboratory

University of Regina - Engineering and Applied Science - Software Systems Engineering

Lab Instructor: [Adam Tilson](mailto:Adam.Tilson@uregina.ca)

---

## Objective

The purpose of this lab is to see how to code a the network interactivity for an application. In particular, we will create a multiplayer game using the Godot Game Engine, a MIT-licensed, cross-platform free and open-source game engine great for rapid prototyping due to user friendly features such as the python-like GDScript, built in patterns and features such as singletons (AutoLoads), observers (signals), groups and a high-level network interface. We will examine a simple battle game ready for multiplayer integration.

## Equipment

A Windows, Mac or Linux computer. The Godot game engine runs as a standalone executable on any operating system, and integrates the engine and IDE in a single application.

## Part 1: Godot Overview

To get started, download the version of Godot needed for your 

![](res/dl-godot-1.png)
![](res/dl-godot-2.png)
![](res/new-project.png)
![](res/create-folder.png)

Unzip, run the executable, and this is the entire game engine, IDE, everything. Cool!
- On MAC you may need to give Godot permissions to run in your system settings
- Leave the console window open, if you close it godot will close!

![](res/ui.png)

The UI of Godot is surprisingly dense, which every area being very useful, though it may not be apparent for what right away.
1. The File Menu
   - Standard things like saving, exporting, setting preferences
   - `Project` -> `Export` is useful for making binaries (but you need to download export templates first!)
   - In particular, `Project` -> `Project Settings` is very important for setting the main scene, setting up AutoLoads, setting controls, etc.
2. The Scene Tree
   - This is where you compose the current scene of nodes
3. FileSystem
   - This is where you can see the assets imported into the current project
4. Switch between 2D/3D/Code/Asset Library
   - The 2D view is used for 2D games and UI
   - The 3D view for 3D games
   - Script for writing GDScript
   - AssetLib for downloading community creations
5. Center Stage - Drag around elements, or Code
   - This is where you arrange elements, or code
6. Output, Debugger, Audio and Animation
   - When debugging code, you'll see important stuff down here
   - Also useful when animating
7. Play and Switch GL Mode
   - This is where you can demo your project or scene
8. Inspector and Node
   - This is where you can set properties of the selected node
   - You can also attach and modify resources here
   - Additionally, you can attach signals in the `Node` menu

Once you switch into script mode, the codding interface replaces center stage:

![](res/coding.png)

### Overview and Help

- An overview of the Godot Engine

[The official godot docs](https://docs.godotengine.org/en/stable/index.html)

### Scenes and Nodes

The fundamental building blocks of the Godot engine are Nodes
- Equivalent to classes
- The engine has many of these already created for you
  - e.g. `Node2D` is a simple container which exists in 2D space
    - `Node2D` has a number of properties you can set, either from the Inspector or Code, such as Position (Vector2D)
    - All 2D classes will be subclassed from Node2D, inheriting it's properties and methods
      - A Sprite is a subclass of Node2D, meaning, it will inherit the position property, but will also have its own
    - `Node2D` has an array of `children` which are of type `Node2D`, allowing of any type
      - Because all nodes inherit from Node2D, all nodes support composition
- Some nodes need resources to be created and attached to have complete functionality, such as Sprites or Materials

- You can search for the predefined types by attempting to add one to the game tree
  - You can read more about the types in docs

- You can subclass nodes to create your own nodes by adding a script
  - This allows you to extend the functionality through code
  
- Your custom node trees can be saved as a Scene (tscn) and re-used
  - This is similar to prototyping in other languages

Example: A simple physics example
- Ensure you are in 2D mode
- Add a root `Node2D` by selecting 2D scene

![](res/root-node.png)

- Add a StaticBody2D

![](res/add-static-body.png)

  - Attach a Sprite to the StaticBody2D
  
![](res/add-sprite.png)

    - Some nodes need resources ro function properly. 
    - Load in a sprite resource, using the default PNG

    ![](res/add-sprite-png.png)

  - Attach it a CollisionShape2D to the StaticBody2D

    ![](res/add-collision-shape.png)

    - Give it a collision shape resource
    - This will be the boundaries for collisions

    ![](res/shape-resource.png)

      - Resize the collision shape extents to match the sprite

        ![](res/resize-collision.png)
  
- Follow the same process with a RigidBody2D
  - Attach a Sprite
    - Load in a sprite resource, using the default PNG
  - Attach it a CollisionShape2D
    - Give it a collision shape resource
      - Resize the collision shape extents to match the sprite

- Group together the StaticBody and it's children so they move together
  - Do the same with the RigidBody

    ![](res/group-together.png)

- Move the RigidBody2D on top of the StaticBody2D
  - Play (Save scene as `demo.tscn`!)
  - You may wish to set it as the default scene too!

    ![](res/preview.png)

- If it is falling too slowly, you can increase the mass of the object in `Scene` -> `RigidBody2D` -> `Inspector` -> `RigidBody2D` -> `Gravity Scale`. Maybe 3 or 4 is okay?

- Duplicate a few of the RigidBody2Ds and move them around and rotate
  - Ctrl D, and use these tools for positioning
- Make the static body bigger to catch them
  - Play again! Neat

    ![](res/rearranged.png)


[Getting started with nodes](https://docs.godotengine.org/en/stable/getting_started/step_by_step/scenes_and_nodes.html)

### GD Script

The default scripting language used in Godot is GDScript.
- The syntax of this language is very similar to python
- Let's use code to "jump" one of our RigidBodies when "Space" is pressed.

First attach a script to the RigidBody

![](res/attach-script.png)

Attached scripts are akin to classes, so we should give it an appropriate name:

![](res/jumping-box.png)

This is GDSCript. It is similar to Python.

Note that our class extends RigidBody2D. This is because we attached it to a RigidBody2D. Through inheritance, we can use any of the properties and methods available in that class.

The two main entry points are the _ready, and _process functions, which are automatically invoked by the engine when the object is created (`_ready`) and every frame the object lives (`_process(delta)`). We are going to add another function called `_physics_process(delta)`. This is similar to process, but is called each time the physics engine updates.

To see which parts of the RigidBody we can access, [check out the docs](https://docs.godotengine.org/en/stable/classes/class_rigidbody2d.html)

We'll directly apply a 

```python
extends RigidBody2D

func _physics_process(delta):
	if Input.is_action_just_pressed("ui_accept"):
		linear_velocity = Vector2(0,-500)
```

Note, these controller buttons can be customized from `Project` -> `Project Settings` -> `Input Map`
Also note that Vector2's are coordinate pairs corresponding to x,y pairs, where the origin is in the top left of the screen.

[GDScript Basics](https://docs.godotengine.org/en/stable/getting_started/scripting/gdscript/gdscript_basics.html)

### Signals

In Godot, Signals implement the observer pattern

- You can find signals attached to certain objects, which are observable states
- You can wire them up to scripts so that, when that signal is called, you can handle that event
- This is also similar to event systems with callback
  - These are found in `Node Pane` -> `Signals`
  - Let's wire the `body_entered` signal on the RigidBody2D to itself:

- Let's use a signal to detect when the RigidBody collides with the floor, and when it does, bounce it back up:

![](res/wiring-signal.png)

Let's add some code too:

```python
func _on_RigidBody2D4_body_entered(body):
	if body is StaticBody2D:
		apply_impulse(Vector2(0,0), Vector2(0,-500))
```

Finally, we need to configure the RigidBody2D to report collisions, since it does not by default:

![](res/contacts-report.png)

[Signals](https://docs.godotengine.org/en/stable/getting_started/step_by_step/signals.html)

### Custom Scenes

We've done a lot of configuration work on the RigidBody2D. We should break it into it's own scene for reuse:

`Right Click` -> `Save Branch as Scene`
- Save it as `JumpingBox.tscn`
- Remove the other instances of RigidBody2Ds, and replace them with JumpingBoxes

With the combination of the scene and the script, this now acts as a self-contained class!

![](res/adding-custom-scenes.png)

Cool, now all of our boxes are jumping!

### Groups

What if we had several different static bodies, and we wanted to bounce on them all?
We could put them in a group to easily find them:

![](res/add-to-group.png)

Now we can modify our code to only work for the group.

```python
func _on_RigidBody2D4_body_entered(body):
	var floors = get_tree().get_nodes_in_group("floors")
	if body in floors:
		apply_impulse(Vector2(0,0), Vector2(0,-500))
```

This would be useful if we had other StaticBodies, for example, walls

[Groups](https://docs.godotengine.org/en/latest/tutorials/scripting/groups.html)

### AutoLoads

`AutoLoads` are scripts which are loaded at the time the game is instantiated. There is thus one globally accessible reference. This is an implementation of the Singleton design pattern.

We can access the AutoLoads from the menu `Project` -> `Project Settings` -> `AutoLoad`

Let's create an AutoLoad script for spawning blocks at regular intervals:

Create a new GDScript `Spawner.gd`, and add in:

```python
extends Node

var timer
var spawn_interval = 1.0

var jumping_box_scene = preload("res://JumpingBox.tscn")

func _ready():
	timer = Timer.new()
	timer.set_wait_time(spawn_interval)
	timer.set_one_shot(false)
	timer.connect("timeout", self, "_on_timer_timeout")
	timer.set_autostart(true)
	add_child(timer)

func _on_timer_timeout():
	var y = rand_range(0,-100)
	var x = rand_range(300, 900)
	var new_block = jumping_box_scene.instance()
	new_block.position = Vector2(x,y)
	get_tree().get_root().add_child(new_block)
```

And attach the script like

![](res/add-autoload.png)

You could stop the time from any script like:
```
var Spawner = get_node("/root/Spawner")
Spawner.timer.stop()
```

Of if you prefer, you can add PlayerVariables directly to the local namespace by `Enabling` the singleton.

[Singletons (AutoLoad)](https://docs.godotengine.org/en/stable/getting_started/step_by_step/singletons_autoload.html)

## Part 2: The Game Offline (Phase 1)...

The Game we are going to add network multiplayer to is as follows:

Goal: 
    - Stomp on other players to gain a point
      - When you stomp on a player they respawn
    - If you fall off the stage you lose a point

Controls:
    - Arrow Keys or WASD to move
    - Jump (Up when on the ground)
    - Ground Pound (Down when in air)
    - Air Dash (Double tap right or left when in air)
    - Drop though floors (Double tap down when on a drop-through floor)
    - Wall Jumps (Up while pressing into a wall)

Find the starter code on URCourses...
  - Note that it is in 3 phases, before multiplayer, with Lobby support but no extras, and with completed. 

A brief walk through the classes:

GameLogic (`GameLogic.gd`)
- Instantiates players in the `_ready` function
- Handles scoring
- Awards points

Spawner (`Spawner.gd`, `Spawner.tscn`)
- Locations in the game where players will score
- Spawners have a cool-down which prevents respawning a player in an area too quickly
- Additionally, spawners all added to the group `spawners`.

Player (`Player.gd`, `Player.tscn`)
- A monster class
- Handles player movement
- Also handles respawning players
- Also handles score

OneWayWall (`OneWalWall.gd`, `OneWayWall.tscn`)

- Identifies walls which the player can drop through

BattleField (`BattleField.tscn`)

- The default arena for the game, composed of other objects

Based on this, what do you believe you would need to send over the network to make this game run?

## Part 3: Low-Level Multiplayer

Godot supports low-level multiplayer 
- This basically allows one to establish a connection over TCP
  - And then send packets
- You can also send packets over UDP
- These are raw data - you can send whatever you want
  - That means the server listening on the other end can be in any language, e.g. Python
  - The server can perform error checking, and ensure no data tampering has occurred
- However this is much harder that what we'll work with
  
- Recall in last lab's Ethernet-TicToc we saw how TCP had a significant amount of overhead when a connection was first established. This is unnecessarily slow for games
  - Also, recall how UDP packets were faster, but delivery was not guaranteed.
    - This too can be not great for games
- Instead, we need something a hybrid - we need the speed of UDP and the reliability of TCP
  - Developers would typically code their own protocol, on top of UDP, for guaranteeing delivery, e.g. with custom ACKs.

For this course, we will instead look at the high level multiplayer, which is such a system built into the Godot engine.

## Part 4: High-Level Multiplayer

High level multiplayer concepts

### (Let's all go to) The Lobby (Phase 2)

The first part of most multiplayer games is a lobby where we manage connections
- If you are a client, you need to specify which IP to connect to
- Recall `127.0.0.1` is the loopback address, also known as localhost, meaning connect to the local device

My lobby has been borrowed from the [Bomberman-style Multiplayer Example](https://godotengine.org/asset-library/asset/139)

- Modifications from Phase 1:
  - Added `lobby.gd`
    - This make heavy use of UI and signals
  - Added `lobby.tscn`
  - Added `gamestate.gd` (AutoLoad)
    - Migrated all of the spawning code from `GameLogic.gd` into `gamestate.gd`

  - Change `lobby.tscn` to the main scene to load
    - This is done in `Project` -> `Project Settings` -> `General` -> `Application` -> `Run` -> `Main Scene`

You can open two instances of godot and open two instances of the project, run them each, and have them to connect with each other. You will get warnings if you modify anything while both are open though. 

Important - when players are created, they are given unique network id's in the `gamestate.gd`
- It might be worth looking at `gamestate` -> `pre_start_game` where players are instantiated and added to the tree.
- In particular, the Host always gets `p_id = 1`. Every other player gets a large random int.

Right now we have two unique instances of the game which have the ability to to communicate between them, but they are not sharing all of the data needed to synchronize gameplay. We need to figure out how to make that communication such that each instance can only control their player, and the game state gets updated appropriately.

### Design for Network Application

[Godot High Level Multiplayer](https://docs.godotengine.org/en/stable/tutorials/networking/high_level_multiplayer.html)

The purpose of our application is to have the Game State synchronized between the players
- Most importantly is the score, as this determines the winner
- But also, in order for players to see where the other players are, and dodge them, their position needs to be updated too
  - What happens if we only sync position?
  - What happens if we synchronize both position and velocity?
    - This leads to an important concept - `prediction` 
      - If we are given gaps in information, can we fill in the bits we don't know with the physics engine?

- Finally, how should we handle movement?

- What should each player be in charge of?
  - Players should be in charge of their movement.
    - I am the one true source of knowledge on my location
      - Everyone else is just observing
  - Players could also be in charge of when they are defeated
    - This leads to another important concept - security and tampering - what if this were disabled.

Together these considerations point to three important concepts to consider are: performance, reliability and security.

### Technical implementation details in Godot:

In our app, `Lobby` runs first and manages connections
Next, gamestate creates the `Player` class, one per connected peer per game
  - So if two players are playing, each player game has two copies of the Player class
    - Four total Player classes across two games!
  - GameA is in control of PlayerA, GameB is in control of PlayerB
    - The copy of PlayerB in GameA is just a puppet, observing the state of PlayerB in GameB
    - Ditto for PlayerA in GameB

`rpc` functions are Remote Procedure Calls. They call a function on other devices, assuming those devices have permission. 
- Permission are given by keywords before the function:
  - `remote` - the function is only called from a remote peer
  - `remotesync` - the function is called remotely and locally
  - `master` - a delegated network master has the ability to call this function
  - `puppet` - non-network masters will instead use this function
- `rpc`s have reliable and unreliable variants

`rset` is how to remotely synchronize a variable
  - as with `rpc`, there are reliable and unreliable versions
  - `master` / `puppet` make sense in this context, for example, as a player you are the `master` of your location. The copy of your player appearing in everyone else's game is merely a `puppet`. 

## Part 5:Peer-to-peer Application

To add network functionality to our application, we must make the following changes:

1. Modify `is_controllable` bool to `is_network_master()` 
    - You need to also remove setting controllable from in `gamestate.gd`

2. Modify position to be a synchronized variable
   - In particular, you will want to create a puppet position and puppet velocity in addition to the true ones
   - And update them using the `rset` or `rset_unreliable` functions

3. Instead, we could modify both position and velocity. What are the benefits to this approach?

4. Ensure that award_point is a synchronized function
   - This ensures that it gets called on all clients

5. In the go_to_timeout() function, ensure that it only runs if you are the network master
    - All others will simply do nothing.
    - Position will thus be handled by it being a synchronized variable
    - We should also make sure the score decrements as an RPC!

The stage three code, included has this functionality implemented. I also did some other things to make your life easier with the assignment that were not originally covered in stage 2, such as allowing any player to start the game rather than just the host. 

## Lab Assignment

There are two parts to this lab assignment.

In part 1, you are to modify the game so that, rather than being implemented as peer-to-peer application, it is instead a dedicated client-server architecture
  - This means that the server could be deployed to the cloud and run without any human interaction
   - In other words, the server, aka the hosts, does not have a character in the game. 
     - Instead it merely acts as an intermediary between the clients.
   - Maintain all other aspects of functionality - do not change any data structures.
     - It should work with clients from Phase 3 with minimal changes (simple not spawning a player with network id 1)

Procedure:
    - Make two copies of the code from Phase 3
      - Even if you followed along with the network examples, please start from the Phase 3 provided
        - I added some extra stuff to reduce some headaches
    - Rename one into `client`
    - Rename the other into `server`
    - Modify the client and server code such that there is no player assigned to the host.
      - The host should automatically be in the waiting for players mode when no game is playing, and return there when a game ends
        - You may wish to see how the `lobby` works, and skip the first screen
      - Thus, no interactivity should be required by the server.
        - However, the client will still show the game in progress visually
      - The client should no longer be able to host
    - Don't overthink this - there changes are on the order of 10 lines of code!

In part 2, make a third version of code called `cheat-client`, which is a version of the client which cheats in some way.
   - The cheats should work with the server logic, i.e. not cause a crash
   - As we are not validating legal data, these should go undetected by the server, and give some advantage in the game.

For marking this lab, we will do a live demo next week. You will meet me in a breakout room, connect to my server, and use your modified client to demonstrate your changes.

## References

J. Linietsky, A. Manzur, Godot Community, [The Godot Docs!](https://docs.godotengine.org/en/stable/index.html), \[Online\]

BornCG, [Let's Build a 2D Platformer!: Part 1](https://www.youtube.com/watch?v=HvPTSZl2WCc). YouTube.com. Apr 6 2020. \[Online\]
