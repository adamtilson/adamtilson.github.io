---
layout: default
title: ENSE 374 Lab 8
---

# Lab 8: MySQL and MongoDB

ENSE 374 - Software Engineering Management - Laboratory

University of Regina - Engineering and Applied Science - Software Systems Engineering

Lab Instructor: [Adam Tilson](mailto:Adam.Tilson@uregina.ca)

---

## Objective

This lab introduces databases. In particular, we will discuss MySQL, since it is a more structured database language, and then MongoDB which is typically used in Node stack applications.

## Equipment

Computer running Windows, MacOS or Linux, with an Intel or AMD-based processor (x86 or x86-64) with administrator privileges. 
- A modern web browser, with a strong preference for Firefox or Chrome
- A text editor, preferably VS Code

## Part 1: SQL

[Basic tutorial on W3Schools](https://www.w3schools.com/sql/default.asp)

Trying out SQL: 

Find an online SQL Playground such as [sqlite online](https://sqliteonline.com/)

Table

|games|
|---|
|id|
|name|
|price|

Rows

|*id* | name | price|
|---|---|---|
|1|Gone Golfing|4.99|

### Setup

```sql
CREATE TABLE games (
   id INT NOT NULL,
   name STRING,
   price MONEY,
   PRIMARY KEY (id)
)
```

![](res/games.png)

### Create

```sql
INSERT INTO games VALUES(
    1,
    "Gone Golfing",
    4.99
)
```

To see the results, right click on your table in the left and do a `SELECT (Show table)`

![](res/first-add.png)

```sql
INSERT INTO games(
    id,
    name
)
VALUES(
    2,
    "Outlast"
)
```

![](res/partial-add.png)

This is fine, but you can't leave out ID!

### Read

```sql
SELECT * FROM games
```

or

```sql
SELECT * FROM games WHERE id=2 
```

![](res/select-with-where.png)

There are more fancy comparators too.

### Update

```sql
UPDATE games
SET price = 22.79
WHERE name = "Outlast"
```

![](res/price-update.png)

Adding Columns?

```sql
ALTER TABLE games
ADD rating INT
```

![](res/alter.png)

No default, gotta go back and add them! Can you update to:

|*id* | name | price|rating|
|---|---|---|---|
|1|Gone Golfing|4.99|85|
|2|Outlast|22.79|80|

![](res/rating-updates.png)

### Delete

Dangerous, don't run without a WHERE, or you could remove all rows!

```sql
DELETE FROM games
WHERE name = "Outlast"
```

better

```sql
DELETE FROM games
WHERE id = 2
```

### Relationships

```sql
CREATE TABLE ratings (
    id INT NOT NULL,
    game_id INT,
    review STRING,
    PRIMARY KEY (id),
    FOREIGN KEY (game_id) REFERENCES games(id)
)
```

![](res/ratings.png)

```sql
INSERT INTO ratings VALUES (
    1,
    1,
    "An ordinary game about mini golf, nothing strange here"
)
```

```sql
SELECT games.name, games.rating, ratings.review
FROM ratings
INNER JOIN games ON ratings.game_id = games.id
```

![](res/inner-join.png)

## Part 2: NoSQL and MongoDB

### SQL vs NoSQL

Structured Query Language vs. Not only Structure Query Language
- SQL: MySQL, PostgreSQL
- NoSQL: Mongo, Redis
  
|SQL               |NoSQL|
|---|---|
|Old Reliable      |New and Cool|
|Tables            |Collections|
|Records / Rows    |Documents|
|Schema Enforced   |Schema Optional|
|Relational!       |Only kinda relational|
|Scales Vertically |Scales Horizontally|

Comparable to C++ vs JavaScript objects - in C++ all fields must be filled, in JavaScript it can be ad-hoc.

### Installation

This procedure will discuss Windows. Download the Community Server from their website...

![](res/download.png)

Download the MSI. (276 MB)
- Run it...
  - `Complete` Install.
  - Install as a Network Service User
  - Do not Install Mongo Compass
  - Reboot is required...
    - I will let you back in.

![](res/install-config.png)

**Keep track of these directories, we'll need them in a bit!**

![](res/no-compass.png)

Make an Alias file:

Open powershell and open your powershell profile:

```
notepad $profile
```

If you get an error that the path doesn't exist, then you can create it with:

```
New-item -Path $profile -ItemType File -Force
```

Then attempt to open the file again.

Now paste in:

(Note, your directories may be different than mine! Keep track in the previous section!)

```
Set-Alias mongod "C:\Program Files\MongoDB\Server\5.0\bin\mongod.exe"
Set-Alias mongo "C:\Program Files\MongoDB\Server\5.0\bin\mongo.exe"
```

Save, close, and restart powershell.

If you get text warning you you can't run scripts, you will need to:

- Open a powershell as an administrator
- Run the following:
  - `Set-ExecutionPolicy Unrestricted`
  - Restart all powershell instances

Create a data directory

create the folders:

`c:/data`

and

`c:/data/db`

<!-- I learned when you just run mongo, it loads up the default, unless it can find mongo.conf-->

This is where your databases will be stored.

Check it is working with:

```
mongo --version
```

![](res/working-on-windows.png)

### Installation guides

[Linux](https://docs.mongodb.com/manual/administration/install-on-linux/)
[Ubuntu](https://docs.mongodb.com/manual/tutorial/install-mongodb-on-ubuntu/)
[Mac](https://docs.mongodb.com/manual/tutorial/install-mongodb-on-os-x)
[Windows](https://docs.mongodb.com/manual/tutorial/install-mongodb-on-windows/)

- in Linux in particular, you need both the `server` and the `shell`

### mongod

- `mongod` is the mongo demon
- It runs the database as a service, and allows you to connect 
to it from a client
- Needs to run as sudo in linux.
- To connect to the database, open a second terminal, and run `mongo`, the Mongo shell

### Help

To show help, run...

```
help
```

### Mongo shell

```
mongo
```

- Command line application to perform database operations

### The Database (db)

The largest data structure in mongo db is a database (db). These are further composed of collections which is further composed of documents. We can compare this to SQL:

|sql| mongo|
|---|---|   
| database | db |
| table | collection |
| row | document |


To show databases:

```
show dbs
```

Mostly these will just be the defaults to start.

### Creating a database

We can create or use a db with...

```
use testdb
```

However, if we check it again with...

```
show dbs
```

- The database still hasn't created until we add a document
- Unlike in MySQL where everything is created first and then objects are stored, NoSQL is more ad-hoc, with containers only appearing once they contain data.

Check the current db with...
```
db
```

### Collection

These are like tables in SQL 
- a collection of documents
  - where documents are like table rows or records

```
show collections
```

However, we haven't created the collection yet! 
- Again, it's ad-hoc. 
  - We need to insert a document into the collection in order to create it.

## Part 3: Mongo DB CRUD Operations

Common database operations are defined by the acronym `CRUD`: Create, Read, Update, Delete

[Read the Manual!](https://docs.mongodb.com/manual/crud/)
- Adam's Docs review: actually pretty good!

### CREATE

You can insert elements into the database with the following functions:

```javascript
db.collections.insertOne( ... );
db.collections.insertMany( ... );
```

The parameters are javascript objects.

e.g.
```javascript
db.games.insertOne(
    {
        _id: 1,
        name: "Gone Golfing",
        price: 4.99
    }
)
```

### READ

To find an element from our collection, use:

```javascript
db.games.find()
```

Which shows all of the games.

We can also pass a json object into find( ... ) to only match certain criteria. 
- returns "Projections" - slices of the collection which contain only the relevant data!

[Query Selectors let you find objects based on Comparisons](https://docs.mongodb.com/manual/reference/operator/query/)

```javascript
{ price: { $gt: 1 } } 
```

Note the funky nested object syntax!

```javascript
db.games.find({ name: "Gone Golfing" })
```

Note the following, which will return nothing:

```javascript
db.games.find({ price: {$lt: 2.00} })
```

|operator|use|
|---|---|
|$eq|Matches values that are equal to a specified value.|
|$gt|Matches values that are greater than a specified value.|
|$gte|Matches values that are greater than or equal to a specified value.|
|$in|Matches any of the values specified in an array.|
|$lt|Matches values that are less than a specified value.|
|$lte|Matches values that are less than or equal to a specified value.|
|$ne|Matches all values that are not equal to a specified value.|
|$nin|Matches none of the values specified in an array.|
|$and|Joins query clauses with a logical AND returns all documents that match the conditions of both clauses.|
|$not|Inverts the effect of a query expression and returns documents that do not match the query expression.|
|$nor|Joins query clauses with a logical NOR returns all documents that fail to match both clauses.|
|$or|Joins query clauses with a logical OR returns all documents that match the conditions of either clause.|

### UPDATE

We need to use syntax similar to Find to find the document we want to update, and then we can add a new record as needed

```javascript
db.games.updateOne({ name: "Gone Golfing" }, 
                   { $set: { price: 2.99 } });
```

### DELETE

```javascript
db.games.deleteOne({ _id: 1 });
```

We can also remove an existing database with the following command:

```javascript
db.dropDatabase();
```

## Part 4: Relationships

A common practice in databases design, to avoid redundancy, is for a document to reference to a second document for more information. These secondary documents can be either embedded, such that the entire entry exists each place it is needed, or referenced, so that only a single referenced document exists which can be referenced multiple times.

There are several types of relationships:

One to One
- If each user has exactly one unique game, you could use an embedded approach

One to Many 
- If one game has many reviews, it may make sense to use the embedded document approach.

Many to Many
- If many users have many games, and vice versa
  - A reference approach is preferred

### Embedded

Example, we can create reviews in array notation:

```javascript
db.games.insertOne(
    {
        _id: 1,
        name: "Gone Golfing",
        price: 4.99,
        reviews: [
            {
                userName: "Adam",
                rating: 1,
                review: "Bug in the first screen"
            },
            {
                userName: "HorrorFan",
                rating: 5,
                review: "Classic"
            }
        ]
    }
)
```

### Reference

```javascript

db.users.insertMany(
    [
        {
            _id: 1,
            userName: "James Games"
        },
        {
            _id: 2,
            userName: "Robin Speedruns"
        }
    ]
);

db.games.insertOne(
    {
        _id: 1,
        name: "Gone Golfing",
        price: 4.99,
        reviews: [
            {
                user_id: 1,
                rating: 1,
                review: "Bug in the first screen"
            },
            {
                user_id: 2,
                rating: 5,
                review: "Classic"
            }
        ]
    }
)
```

We could match the user to the review by looking up in both tables:

```javascript
db.users.find({ 
    _id: db.games.find()[0].reviews[0].user_id
})
```

### Schemas

If the ad-hoc nature of MongoDB is too frustrating for you, you can also define schemas, which are more like table templates
- list the fields that you need
- list dataTypes for those fields
- list of those fields are required
- list default values for them
- You can do this in Mongo, we'll do this in Mongoose in just a bit!

## Part 5: Mongoose

Mongoose is a Node.js library for connecting to your database, and performing database operations. It can be triggered by any code in your Node.js script, but you will most likely want to use it on your routes.

*Always make sure `mongod` is running!*

### What is it?

The default driver for mongo for Node.js is a little bit tedious.
- A theme in this class is introducing tools to make your life easier
- These are also widely used in Industry

### Installation

```
npm i mongoose
```

### Boilerplate

Modified from the front page:

```javascript
// Bring in mongoose
const mongoose = require( 'mongoose' );

// connects to the "test" database (ensure mongod is running!)
// the later arguments fix some deprecation warnings
mongoose.connect( 'mongodb://localhost:27017/test', 
                  { useNewUrlParser: true, useUnifiedTopology: true });

// create a schema
const Cat = mongoose.model( 'Cat', { name: String });

// create a document following that schema
const kitty = new Cat({ name: 'Zildjian' });
kitty.save().then( () => console.log('meow') );
```
That's all it takes to do database stuff from Node! Let's look at these in more depth...

### Creating a Schema

Creating a schema for our game example:

```javascript
const gameSchema = new mongoose.Schema ({
    name: String,
    rating: Number,
    price: Number,
    review: String
});
```

There are explicit data types assigned, as in SQL. These are called SchemaTypes. [Read the docs for more info!](https://mongoosejs.com/docs/guide.html)

Types:

- `String`
- `Number`
- `Date`
- `Buffer` 
- `Boolean` 
- `Mixed`
- `ObjectId` 
- `Array`
- `Decimal128` 
- `Map`

If you omit _id, then Mongoose will add it for as a unique ObjectID. Or you can be explicit, but you must ALWAYS set one, or it will not save.

### Using a Collection

```javascript

// this creates a collection called `games` (Weird, but intuitive)
const Game = mongoose.model ( "Game", gameSchema );
```

### Adding a Document

We want to add a new game document to our games collection

```javascript
const game = new Game({
    name: "Gone Golfing",
    rating: 5,
    price: 4.99,
    review: "classic"
});

game.save();
```

Typically you run this once from a node.js script, and then comment out the save lines to prevent multiple identical copies of things in your DB!
- You likely won't want nodemon running here when doing database tests, instead just use `node app.js`
  - Otherwise every time you do an update, expect more copies in the database!

Also, make sure you have `mongod` server running in a separate terminal!

Let's use mongo shell and find our game. From a separate terminal

```
mongo
use test
db.games.find()
```

A few extra entries were added, but it's basically what we expect:

```javascript
> db.games.find()
{ "_id" : ObjectId("617747c24de34db695e58f96"), "name" : "Gone Golfing", "rating" : 5, "price" : 4.99, "review" : "classic", "__v" : 0 }

```

### Mongoose Help

[The docs. That are... just okay.](https://mongoosejs.com/docs/guide.html)

### Important Aside: Async Javascript

- In modern JavaScript, it's important to write non-blocking code
  - i.e., if an operation is slow, rather than waiting for it, we can allow other operations go first
    - e.g. Database operations take time, especially for big databases on slow hard drives!
  
- `async` is a modern JavaScript keyword that allows this
  - Signified by a function with the `async` keyword
  - Rather than returning a value, it returns a "promise" that it will return a value, once it completes.

- Previously, once the operation is complete, you can resume execution via a callback function
  - In much the same way in JavaScript DOM we used callbacks to wait for a user to click a button, and then did something
  - In this case we are waiting for the database to read, and then do something in a callback
    - The problem - what if you need to wait for one thing, which waits for another things, which waits for another
    - It can lead to nested callbacks and callback hell

- Thus, we'll make use of the `async`/`await` syntax.
  - This code reads like it's synchronous, but it's not
  - I think it leads to cleaner code, better for when learning. 

*The reason we are forced to look at this is now is: Mongoose has no synchronous API! We have to use async, either through callbacks, promises, or async/await*

### Reading from a MongoDB

Here's doing a find operation using callback syntax:

```javascript
Game.find({ name: "Gone Golfing" }, ( error, results ) => {
    if ( error ) {
        console.log( error );
    } else {
        console.log( results );
        if ( results.length === 0 ) {
            console.log( "no results found" );
            return;
        }
        // this is where we have access to our results
    }
});
```

Or we can use the `async`/`await` syntax. 
```javascript

async function findInDatabase() {
    try {
        const results = await Game.find({ name: "Gone Golfing" });
        console.log(results);
        if ( results.length === 0 ) {
            console.log( "no results founds" );
            return;
        }
        // this is where we have access to our results
        
    } catch ( error ) {
        console.log( error );
    }
}

findInDatabase();
```

While these may seem similar, if you are doing repeated calls which require the results of multiple functions, your code can get very deeply nested in the callback approach.

Enough syntax talk, what does our code actually do?

- returns an array of our games in a JavaScript object called 'results'
  - We can traverse it just like any other JS Object
  - Can we use `for...of` loops? Yep!
  - Can we pass it to EJS and use it there? Yep!

### Closing the connection

The last time you use Mongoose, you should close the connection

```javascript
mongoose.connection.close();
```
- e.g. in the last find callback.
- In our server operations, the server will stay open, so we don't need to explicitly close

### Update 

Here we can do an async update by creating an async anonymous function and immediately calling it:

```javascript
(async () => {
    try {
        await Game.updateOne( { gameName: "Dead Space"}, 
                              { $set: { rating: 1 } });
        await Game.updateOne( { gameName: "Dead Space"}, 
                              { $set: { review: "Needs a remaster already!" } });
    } catch (error) {
        console.log(error);
    }
})();
```

This is an example where the await syntax avoided us nesting callbacks 

### Delete

Back to callback syntax:

```javascript
Game.deleteOne ( { name: "Gone Golfing" }, ( err ) => {
    if (err) {
        console.log (error)
    }
});
```

There is also a deleteMany function.

### Adding Relationships

To add a relationship, we need to create a schema

```javascript
const personSchema = new mongoose.Schema ({
    name: String,
    age: Number,
    favouriteGame: gameSchema
});
```

The syntax makes it appear as if we are embedding a document, but it's actually a reference. Neat!

## Part 6: Full example

Let's create a form for users to rate games. Users can enter their name, the game name, score, and rating text. They will then be taken to a page that lists all scores.

Project setup:
```
eg-mongoose
|- index.html
|- app.js
|- views
    |- reviews.ejs
```

initializing commands
```
npm init
npm i express ejs
```

and, lets add some text to:

`index.html`

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Reviews</title>
</head>
<body>
    <form action="/submit" method="post">
        <label for="userName">User Name</label>
        <input type="text" name="userName" id="userName">
        <br>
        <label for="gameName">Game Name</label>
        <input type="text" name="gameName" id="gameName">
        <br>
        <label for="score">Score</label>
        <input type="text" name="score" id="score">
        <br>
        <label for="reviewText">Review Text</label>
        <input type="text" name="reviewText" id="reviewText">
        <input type="submit" value="submit">
    </form>
</body>
</html>
```

`reviews.ejs`

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Reviews</title>
    <!-- Styles from w3Schools table tutorial -->
    <style>
        table {
          font-family: arial, sans-serif;
          border-collapse: collapse;
          width: 100%;
        }
        
        td, th {
          border: 1px solid #dddddd;
          text-align: left;
          padding: 8px;
        }
        
        tr:nth-child(even) {
          background-color: #dddddd;
        }
    </style>
</head>
<body>
<table>
    <thead>
        <tr>
            <th>User Name</th>
            <th>Game Name</th>
            <th>Score</th>
            <th>Review Text</th>
        </tr>
    </thead>
    <tbody>
        <!-- We want to repeat this for each game in the database -->
        <tr>
            <td>Adam</td>
            <td>Limbo</td>
            <td>5</td>
            <td>Couldn't beat the part with the blow darts.</td>
        </tr>
        <!-- End repeating bit -->
    </tbody>
</table>
</body>
</html>
```

`app.js`

```javascript
const express = require ( "express" );

// this is a canonical alias to make your life easier, like jQuery to $.
const app = express(); 
// a common localhost test port
const port = 3000; 

// body-parser is now built into express!
app.use( express.urlencoded({ extended: true }) ); 
app.set( "view engine", "ejs" );

// Simple server operation
app.listen ( port, () => {
    // template literal
    console.log ( `Server is running on http://localhost:${port}` );
});

app.get( "/", ( req, res ) => {
    console.log( "A user is accessing the root route using get" );
    res.sendFile( __dirname + "/index.html" );
});

app.get( "/reviews", ( req, res ) => {
    console.log( "A user is accessing the reviews route using get" );
    res.render( "reviews" ); //pass data to EJS from the Database here
});

app.post( "/submit", ( req, res ) => {
    console.log( "A user is posting data to the submit route" );
    //write and update the Database here
    res.redirect( "/reviews" );
});
```

We need to:
1. Add the database boilerplate
2. Add a schema
3. Capture data from the form and store it in the database
4. Read from the database and send it to EJS
  - Do this in two places
5. In EJS render all of the data

### Add database boilerplate

- add mongoose with `npm i mongoose`
- in requires:
```javascript
const mongoose = require( "mongoose" );
// connect to mongoose on port 27017
mongoose.connect( "mongodb://localhost:27017/games", 
                  { useNewUrlParser: true, 
                    useUnifiedTopology: true});
```

### Add a schema

After connecting, add the following code:

```javascript
// create a mongoose schema for a game
const gameSchema = new mongoose.Schema ({
    userName:   String,
    gameName:   String,
    score:      Number,
    reviewText: String
});

const Game = mongoose.model ( "Game", gameSchema );
```

### Capture form data into the database 

```javascript
// save into the database on post
app.post( "/submit", ( req, res ) => {

    console.log( "A user is posting the following review" );
    console.log( req.body )

    const game = new Game({
        userName:   req.body.userName,
        gameName:   req.body.gameName,
        score:      parseInt( req.body.score ),
        reviewText: req.body.reviewText
    });

    game.save();

    res.redirect( "/reviews" )
});
```

### Read from the database and send it to EJS

```javascript
app.get( "/reviews", async( req, res ) => {
    console.log( "A user is accessing the reviews route using get, and found the following:" );
    try {
        const results = await Game.find();
        console.log( results );
        res.render( "reviews", { results: results });
    } catch ( error ) {
        console.log( error );
    }
});
```

### Post it using EJS

Let's iterate over the results:

```html
    <!-- We want to repeat this for each game in the database -->
    <% for ( const result of results ) { %>
        <tr>
            <td><%= result.userName %></td>
            <td><%= result.gameName %></td>
            <td><%= result.score %></td>
            <td><%= result.reviewText %></td>
        </tr>
    <% } %>
    <!-- End repeating bit -->
```

## Lab Assignment

The penultimate lab assignment, which will due by demo next week, is to:

- Have MongoDB and Mongoose installed on your local machine
  
- Based on your application at the end of lab 7, create Mongoose schemas for:
  - Your users
  - Your tasks

- Additionally, create code to populate your starter users and tasks into the database from the previous lab
  - Create the schema objects and save them.

- You do not need to completely get all of the functionality of your application working with MongoDB / Mongoose, though that will be part of the final big submission next week, so if you have extra time you could work on that too.
  - If you were careful with your model in the last lab, this shouldn't take too much work to change!