---
layout: default
toc: true
title: ENSE 374 Schedule
---
# ENSE 374 - Software Engineering Management - Laboratory
University of Regina - Engineering and Applied Science - Software Systems Engineering

Lab Instructor: [Adam Tilson](mailto:Adam.Tilson@uregina.ca)

---

## Schedule

Labs will be on Tuesday's and Wednesday's and delivered remotely over Zoom. You may drop into whichever session you prefer. Zoom details will be posted on URCourses.

| Title | Assigned | Due | Grading |
|---| :-:| :-:| :-:|
|[1. Tools: VS Code, Git and GitHub](./lab-1)| Sept 7/8 |Sept 14/15 +| 1%|
|[2. View 1: HTML](./lab-2)|Sept 14/15 |Sept 21/22 +| 2%|
|[3. View 2: CSS & Bootstrap](./lab-3)| Sept 21/22 |Sept 28/29 |4%|
|[4. View 3: JavaScript and DOM](./lab-4)|Sept 28/29| Oct 5/6 +| 2%|
|[5. View 4: jQuery](./lab-5)| Oct 5/6 |Oct 12/13 |4%|
|[6. Controller 1: Node.js & Express](./lab-6) |Oct 12/13 |Oct 19/20 + |2%|
|[7. Controller 2: EJS](./lab-7) |Oct 19/20| Oct 26/27 |4%|
|[8. Model 1: MySQL, MongoDB and Mongoose](./lab-8) |Oct 26/27| Nov 2/3 +| 2%|
|[9. Model 2: Passport](./lab-9) |Nov 2/3 |Nov 16/17 |4%|
|Total Lab Grade: |  |  |  25%|
