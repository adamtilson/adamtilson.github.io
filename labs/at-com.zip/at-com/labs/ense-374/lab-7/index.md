---
layout: default
title: ENSE 374 Lab 7
---

# Lab 7: EJS And Templates

ENSE 374 - Software Engineering Management - Laboratory

University of Regina - Engineering and Applied Science - Software Systems Engineering

Lab Instructor: [Adam Tilson](mailto:Adam.Tilson@uregina.ca)

---

## Objective

This lab introduces EJS, a Node.js library for Embedded JavaScript Templates. With this, we will be able to create Templated HTML files which will contain placeholders for different variables. These variables will be automatically filled from the Express Server using Node.js. Additionally, we can create reusable chunks of files, called Partials, that can be dynamically inserted into pages.

## Equipment

Computer running Windows, MacOS or Linux, with an Intel or AMD-based processor (x86 or x86-64) with administrator privileges. 
- A modern web browser, with a strong preference for Firefox or Chrome
- A text editor, preferably VS Code

## Part 1: Intro to EJS

Recall our stack, as well as our progress so far...

![node stack](res/node-stack.svg)

So far we understand how all of the files on the front end work, as well as how those files get passed over from server. We also looked at how data can be passed to the server with forms, and echoed back from Node.js with and using Express `res.send`. However, we would rather place that data into mostly complete HTML files, and we do not have a method for this yet.

### Template Processing

In the previous lab, we used `express` to answer requests and send data back to the client using `res.send` and `res.sendfile`.

Either we could build the entire HTML page from scratch using `res.send` and HTML tags, or send a completed page with `res.sendfile`.

What if we want to send mostly complete HTML files where only small parts of them get changed, for example a name or a form?

### Example Set Up

Let's continue from our example from last week. To be on the same page...

- create the following files:

```
ejs-eg
  |-- public
  |    |-- css
  |         |-- style.css
  |-- app.js
  |-- index.html
```

- open a terminal in `ejs-eg` folder
- type in `npm init`
  - Accept the defaults (press enter many times)
- type in `npm i express` (`npm i` is shorthand for `npm install`)
- add the following code to each file:

in `index.html`

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>A Sample Page</title>
    <!-- Recall static resource links are relative to the `public` folder-->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1 class="my-heading">This is a heading with a bold background color</h1>
    <form action="/" method="post">
        <label for="my-name">Your Name:</label>
        <input type="text" name="my-name" id="my-name" placeholder="Your name here">
        <input type="submit" value="Submit Your name">
    </form>
</body>
</html>
```

in `style.css`

```css
.my-heading {
    background-color: #97b498;
}

.error-heading {
    background-color: #ba6b6c;
}
```

in `app.js`

```js
const express = require ( "express" );

// this is a canonical alias to make your life easier, like jQuery to $.
const app = express(); 
// host static resources
app.use(express.static("public"));
// body-parser is now built into express!
app.use(express.urlencoded({ extended: true})); 

// a common localhost test port
const port = 3000; 

// Simple server operation
app.listen (port, () => {
    // template literal
    console.log (`Server is running on http://localhost:${port}`);
});

app.get("/", (req, res)=>{
    res.sendFile(__dirname + "/index.html");
})

app.post("/", (req, res) => {
    // template literal
    res.send (`<h1>Welcome to my page, ${req.body["my-name"]}</h1>`)
})
```

You can run your application with

`node app.js`

or

`nodemon`

and then visit your webpage by opening your browser and navigating to:

`http://localhost:3000`

Add some text to the textbox, submit, and verify everything works.

### Installing EJS

You can install EJS with:
```
npm install ejs
```

You can bring it into your express app with:

```javascript
app.set("view engine", "ejs");
```

Remember to call this after you set app to `express`!

## Part 2: EJS Templates and sending variables

### Creating an ejs templated HTML file

You EJS files need to be put in a special directory:

```
/views
```

So, our main file is typically called: `/views/index.ejs`, but we can have others too, like `/views/greeting.ejs`.

Let's create a `/views/greeting.ejs`.

These files are mostly HTML files, e.g. add the following to `/views/greeting.ejs`:
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>A Greeting Page</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1 class="my-heading">Welcome to my page, User!</h1>
</body>
</html>
```

We can preview this page by adding:

```javascript
app.get("/greeting", function (req, res) {
    res.render("greeting")
});
```

`res.render` means to render using the EJS view engine
`"greeting"` means look for a file in called `/views/greeting.ejs`

And then browsing to [http://localhost:3000/greeting](http://localhost:3000/greeting)

Wouldn't it be nice if we could personalize our page with our User's name?

### Variable templates

In your EJS file, where you want a passed variable to be rendered, you use this syntax:
```
<%= variable %>
```

In the `/views/greeting.ejs` file:

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>A Greeting Page</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1 class="my-heading">Welcome to my page, <%= username %>!</h1>
</body>
</html>
```

All of the variables you want to render you need to pass from the server, otherwise you'll get an error!

### Send Variables to the Template

Rather than using send, Passing a variable to a template using the following syntax:

```javascript
app.get("/greeting", function (req, res) {
    res.render("greeting", {username: "Adam"})
});
```

`res.render` means to render using the EJS view engine
`"greeting"` means look for a file in called `/views/greeting.ejs`
The second argument is a JavaScript object of name, value pairs, in this case:
  - `username` is the variable in the EJS file
  - `Adam` is what we wish to write there

And when we preview our page, now we our username will be displayed!

We can pass over any sort of JavaScript object, and access the variables inside using the appropriate properties!

Challenge: Modify your starting code so that when the user enters a name on the index page and submits, they are redirected to the greeting page where the name is displayed.

## Part 3: EJS Control Code

Sending individual variables is useful, but we can actually do more with EJS. We can use EJS Control Structures, and also pass over Arrays and loop through the contents!

Control structures are similar in syntax to JavaScript, though not all of the functionality exists. Each `scriptlet` line is wrapped in `<% %>` tags.

Eg. we can have a conditions:

In `/views/greeting.ejs`, replace:
```html
<h1 class="my-heading">Welcome to my page, <%= username %>!</h1>
```

with:

```html
<% if (username === "Adam") { %>
    <h1 class="my-heading">Welcome to my page, <%= username %>!</h1>
<% } else { %>
    <h1 class="error-heading"> Sorry, I don't know you </h1>
<% } %>
```

We can also use loops:

e.g. looping and rendering items in an array:

in your express route...

```javascript
let fruits = ["apples", "orange", "peach", "mango"];

app.post("/", (req, res) => {
    res.render("greeting", {username: req.body["my-name"], 
                            fruitList: fruits});
});
```

in your `views/greeting.ejs`, after your greeting:

```html
<p>My favourite fruits are:</p>
<ul>
    <% for (let i = 0; i < fruitList.length; i++) { %>
        <li> <%= fruitList[i] %> </li>
    <% } %>
</ul>
```

Other loop structures are available as well.

```html
<p>My favourite fruits are:</p>
<ul>
<% for (let fruit of fruitList) { %>
    <li> <%= fruit %> </li>
<% } %>
</ul>
```

## Part 4: Layouts and Partials

### Static components: Layouts

If you have common static components you wish to use on many pages, e.g. a header or a footer, you can create an EJS layout to include this component.

e.g. in `/views/layouts/header.ejs`
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>A Greeting Page</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
```

and in `/views/layouts/footer.ejs`
```html
<p>2021 BY-NC-SA</p>
</body>
</html>
```

To include this in another page, add the following snippets where you want these components to appear:

e.g. The new entire contents of `views/greeting.ejs`:

```html
<%- include("layouts/header") -%>

<% if (username === "Adam") { %>
    <h1 class="my-heading">Welcome to my page, <%= username %>!</h1>
<% } else { %>
    <h1 class="error-heading"> Sorry, I don't know you </h1>
<% } %>

<p>My favourite fruits are:</p>
<ul>
<% for (let fruit of fruitList) { %>
    <li> <%= fruit %> </li>
<% } %>
</ul>

<%- include("layouts/footer") -%>
```

You can include boilerplate code, css, javascript, whatever you need, so that only the content for that page remains. This is super slick and highly recommended!

This paradigm is used heavily in and expanded on in front-end frameworks like React and Vue, which unfortunately we don't cover in this course.

### Dynamic Components: Partials

Partials are similar to layouts, except you can pass through parameters to further modify them at render time.  

In other words, the variables which are passed to your EJS page from express, can then be further passed to a partial.

These are saved in:

`/views/partials/`

e.g. `/views/partials/list-module.ejs`

Call it with

```html
<%- include("partials/list-module.ejs", { itemList : fruits }) -%>
```

example:

in `/views/partials/list-module.ejs`
```html
<ul>
    <% for (let item of itemList) { %>
        <li> <%= item %> </li>
    <% } %>
</ul>
```

and our final `views/greetings.ejs`:

```html
<%- include("layouts/header") -%>

<% if (username === "Adam") { %>
    <h1 class="my-heading">Welcome to my page, <%= username %>!</h1>
<% } else { %>
    <h1 class="error-heading"> Sorry, I don't know you </h1>
<% } %>

<p>My favourite fruits are:</p>
<%- include("partials/list-module.ejs", { itemList : fruitList }) -%>

<%- include("layouts/footer") -%>
```

Challenge: Can you do the same with the Welcome module?

### Total Data Flow

![](res/total-data-flow.png)

## Part 5: The Model

In lab 5, you likely struggled with your understanding of what a task is, conceptually.
- Is it a DOM element? The text inside an input box?
- How do I tell what state the task is in? 
  - I have to look at surrounding DOM elements to see if there is a button or a checkbox or both?
- This is confusing and hard!
  - And any solutions you come up with for working with them seem very hacky!

![](res/what-is-a-task.png)

This struggle showcases the difficulty when your `model` is not separated from your `view`!

Let's think about the data which is used to describe a task:

- What order the task are tasks displayed in?
- What state is the task in?
- What is the text of the task?
- Who made the task?
- Has anyone claimed the task?
  - If so, who claimed the task?
- Is the task done?
  - Is the task cleared?

We can describe this data as an Object, using `UML Class Diagram` notation:

![](res/class-diagram.png)

With this in your mind, you can be thinking:

![](res/model-vs-view.png)

## Lab Assignment

In this lab you will implement the remaining functionality of the application, but without the added security and database operations which we will discuss in the following weeks. Consider this lab a learning exercise on using node and passing data with the controller: not everything we do will be best practices and should not be followed in production environments!

![](res/jquery.svg)

Note that this application forks from lab 3, most of the JQuery JavaScript (Front End functionality) will be removed from the application in favour of back end functionality.

### Data setup - The Model

Later on, we will store our model in a database. Right now, we'll just create some JavaScript objects to represent both the user and the tasks, and store them in there. The classes should be created as follows:

`User` object:
- username (string)
- password (string)

`Task` object:
- _id (int) - assign sequential numbers, must be unique
- text (string)
- state (string)
- creator (User)
- isTaskClaimed (boolean)
- claimingUser (User)
- isTaskDone (boolean)
- isTaskCleared (boolean)

Create an array of each type of object
- Have an array of two `Users`
- Have an array of five `Tasks`
- The tasks must be:
  - 1 unclaimed task
  - 1 claimed by user1 and unfinished
  - 1 claimed by user2 and unfinished
  - 1 claimed by user1 and finished
  - 1 claimed by user2 and finished 

For unclaimed tasks, the `claimingUser` should be `null`

Additionally, create functions for saving and loading each array to or from a `.json` file, then save them.
- Save them once, them comment out the function call
  - Only save again if the something changes in the lists
- On future runs, load the existing lists!

** Note: It is extremely insecure to save user passwords in plain text objects. Do not use any realistic passwords for any accounts! We will make this more secure in Lab 4! **

### FAQ - How do I store an array into a JSON file?

Use syntax similar to:
```javascript
{"employees":[    
    {"name":"Ram", "email":"ram@gmail.com", "age":23},    
    {"name":"Shyam", "email":"shyam23@gmail.com", "age":28},  
    {"name":"John", "email":"john@gmail.com", "age":33},    
    {"name":"Bob", "email":"bob32@gmail.com", "age":41}   
]} 
```

[Source](https://www.javatpoint.com/json-array)

###  User registration and login

Render the login page on the "/" route.

Give the following functionality to the login page:

Link the login form to the "/login" route with POST. In this route perform the following:
- check through the user list to see if the entered username is registered
- if so, check if the user's password matches the password for the entry
- if so, redirect the user with the POST variables to the "/todo" route.

Link the register form to the "/register" route. In this route perform the following:
- ensure that the sign up `authorization` field matches a constant value of `todo2021`
- check that no users exists with the username entered
- If no users with that name exist, create a new user with the username and password supplied
- finally, redirect with the POST variables to the "/todo" route.

*Be sure to save the updated user list to the JSON file when a user registers*

### FAQ

How do I do a redirect which maintains the form data from one route to another?

Use this syntax:

```javascript
res.redirect( 307, "/newroute" );
```

In order for this to work, you need to have properly configured express to pass arguments like body-parser.

```javascript
app.use( express.urlencoded({ extended: true })); 
```

Make sure this code runs before any `app.listen`, `app.post` or `app.get` calls!

### To-do list display

Use EJS to render the to-do list on the "/todo" route

When rendering the route, ensure the following data is passed to the EJS file
- the logged in user's username (string)
- the list of tasks (array)

On the todo list, render the following:
- The logout block
- The to-do list display
- Each of the different task states:
  - Recall the starting state of the Task list includes one of each:
    - Unclaimed
    - Claimed by the current user but unfinished
    - Claimed by the current user and finished
    - Claimed by a different user but unfinished
    - Claimed by a different user and finished
  - Use EJS Partials to render each of these as partials
- A section for adding new tasks
- A button for removing complete tasks

Any Task flagged as "cleared" should not be displayed

The Tasks should be decorated as in the previous labs.

Hints: 

- Use EJS scriptlet control flow to loop over all of the tasks
    - using EJS scriptlet control flow, task properties and username, decide how to display each task
- when adding a task to the page, use a `hidden` input element to contain the task's _id to uniquely identify it
- Make a unique form for each Task that has interactivity with a unique route, which will be explained in the next section
    - You can submit a form when a checkbox is clicked using `<input onChange="this.form.submit()" ... />`
- You can use a `hidden` input type to store the username of the currently logged in user. 
  - This will automatically pass it back to Node.js when you submit as a POST parameter

** Note: Storing the current user in POST and passing it around via redirects works, but it's not best practice. In lab 4 we'll replace this functionality with sessions**

### To-do list functionality

Finally, code up all of the routes to give your application functionality
Name your routes, use the methods, and implement as follows:

|route|method|purpose|
|---|---|---|
|/logout|get|logs out the user and returns to the main screen|
|/addtask|post|adds a new unclaimed task to the task list, and redirects to "/todo"|
|/claim|post|claims the task for the user who clicks on the claim button, and redirects back to "/todo"|
|/abandonorcomplete|post|checks if the user clicked on abandon or complete, updates the task appropriately, and redirects to "/todo"|
|/unfinish|post|for the selected task, sets the task state to unfinished, and redirects back to "/todo"|
|/purge|post|Set all tasks where "done" is true such that "cleared" is true. and redirects back to "/todo"|

The following state diagram represents state transition for tasks owned by the currently signed in user:

![](res/state-diagram.png)

### Submission

Please submit to URCourses by the due date.