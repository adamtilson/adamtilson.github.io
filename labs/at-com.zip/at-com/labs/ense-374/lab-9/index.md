---
layout: default
title: ENSE 374 Lab 9
---

# Lab 9: Authorization and Passport

ENSE 374 - Software Engineering Management - Laboratory

University of Regina - Engineering and Applied Science - Software Systems Engineering

Lab Instructor: [Adam Tilson](mailto:Adam.Tilson@uregina.ca)

---

## Objective

This lab discusses important concepts for securely storing passwords in a database, and authenticating users. During implementation, we will use Passport, which handles authentication using several strategies. We will use the strategy of registering users in the local MongoDB database using mongoose, supported by a number of plugins to facilitate this process. Additionally, we will discuss sessions, and storing environment variables securely in a .env file.

## Equipment

Computer running Windows, MacOS or Linux, with an Intel or AMD-based processor (x86 or x86-64) with administrator privileges. 
- A modern web browser, with a strong preference for Firefox or Chrome
- A text editor, preferably VS Code

## Part 1: Password Security

### Background

So far our to-do list is functional, but not at all secure. How can we make it more secure?
- What's wrong with what we've done so far?
- What happens if you push passwords to github?
- What about storing them on the cloud?
- What if users use the same password as in other services?

### Encryption

First level of defence: scramble our passwords using encryption

(This section is for information, we'll use a higher level approach!)

- If you haven't already, you'll learn all the math behind this later. (RSA)
- We can use the `mongoose-encryption` package [available on NPM](https://www.npmjs.com/package/mongoose-encryption)
  - We need two Secret strings - these are used to generate our encryption and decryption keys. 
  - They should be kept secret!
  - We then apply the encryption to the Schema using middleware
    - Middleware are libraries which plug into existing applications and extend their functionality
    - The middleware automatically encrypts on a save and decrypts on a read
- Now our system is only as secure as our Secret strings
  - We don't want to just push to github!
  - So how do we store our secret more... secretly?

Is it perfect?
- No, as technology improves, what's secure one day is much less secure the next!

### Environment Variables

We need a method to securely store our Secrets, and other important environment variables.

(We will include this approach in our final product)

- We could use tht `.env` file
  - A hidden file which can stores our secrets in a safe location
  - We can use this for our "Authorization" key in the todo list application. 
    - We could also use it for any API keys

From npm:

```
npm install dotenv
```

In our js file:

```javascript
require("dotenv").config();
```

In our root directory:

Create a `.env` file in the root. 
  - This is the whole name of the file
    - Similar to the `.gitignore` file
  - Save your variables here:

```
DB_HOST=localhost
DB_USER=root
```

No quotations for strings. Multiple words after the equals are fine.

Access in variables in our node js file:

```javascript
process.env.DB_HOST
```

Finally, add this file to your gitignore!
```
.env
```

This will keep the file from getting pushed to the github. 

When you upload your files to the server, securely upload your Environment Variables rather than push and pulling from GitHub!

### Hashing

Next level of defence: Hashing

(This section is for information, we'll use a higher level approach!)

Hash functions are a mathematical equation which turns a string into a hash code
  - Deterministic, so the same input always produces the same hash
  - It's impossible (or at least ridiculously hard) to go backwards 
    - This is called a "one-way function"

We know going forward function call produces consistent results
    - At registration time, we can ask for a password, 
      - hash it, 
      - and store the hashed value in our database. 
    - At login time, the user enters the password
      - the entered password is hashed 
      - and if the hashed value matches what's in the database,
      - the password must be correct!
    - Unfortunately hash functions can have multiple inputs map to the same output, but it's incredibly rare

Example: [MD5 application](http://www.md5.cz/)

How can we beat this?
- Make a hash table of common passwords, and compare.
- Modern GPUs can do 20Bill Hashes per Second!

How else can we improve security?

Use a slow hashing function, like bcrypt
  - This will slow down brute forcing
  - But technology will improve

### Salting and Hashing

Let's upgrade our security one more level:

Add a salt and then hash!

(This is what we'll do, but we'll have Passport do it for us!)

- generate a random string, called a Salt
  - concatenate it to the password
  - hash the whole thing!
    - This will produce a different value than only hashing the password
  - Save the salt into the database too for future reuse
  - When testing new use passwords, 
    - grab the old salt
    - concatenate it to the new password
    - hash the whole thing
    - check that they match

Want more security? 
  - Salting rounds! 
    - salt it, hash it, salt it, hash it, 
    - do it 5 times?
    - each salt/hash round doubles the time to compute it.

Can we do this manually in node? sure!

`bcrypt` [Bcrypt on NPM](https://www.npmjs.com/package/bcrypt)
- you can hash, choose the number of salt rounds, etc.
- However, we'll have Passport do this for us!

## Part 2: Authentication

### Cookies

Once the user is logged in, how do we track which user they are?
    - This is done through cookies and sessions

Cookies are delicious delicacies - Mozilla, 1999
  - a piece of persistent data that is stored on the users browser
    - It can be used to authorize a user by means of an "access token" 
      - a hash which identifies which user is logged in.
  - Cookies persist between visits, which is why you do not need to manually log back into websites

### Sessions

Sessions, on the other hand, persist only during one visit to a website
- A session is one complete dialogue between the client and the server
- You can think of it like a lock being generated on the server side
  - We give the user the key, and store it inside a cookie
  - When the user presents the cookie with the key, if it unlocks, we let them in
  - The sessions ends when the server changes the lock (typically after a certain amount of time), 
    - the user discards the key (when closing the browser)
    - or ideally both (logging out)

- We will be using sessions to keep our users authorized during one visit, until they log out

### Open Authorization (OAuth)

Beyond the scope of this lab but worth mentioning:
- OAuth is the cool new approach and open standard for authorization
- We essentially subcontract another company to do authorization for us
  - Google, FaceBook, GitHub, etc. 
  - The user logs in with their credentials for that account
  - The third party verifies the users identity without exchanging any passwords. Cool!
    - You put all your trust in one company rather than distributing it around

- This is possible to achieve using passport OAuth modules, but we will not look into it for this lab.

## Part 3: Passport Usage and Example

Let's see how this authorization works by example. 
  - We'll build on our Game Review submission application from last week.
  - We are basically starting from where we made it last week, 
    - with some minor adjustments for what we're doing today:

Set up the following directory structure:

```
|-- /views
|    |-- reviews.ejs
|    |-- add-review.ejs
|-- .env
|-- index.html
|-- app.js
```

in `/views/reviews.ejs`
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- Styles from w3Schools table tutorial -->
    <style>
        table {
          font-family: arial, sans-serif;
          border-collapse: collapse;
          width: 100%;
        }
        
        td, th {
          border: 1px solid #dddddd;
          text-align: left;
          padding: 8px;
        }
        
        tr:nth-child(even) {
          background-color: #dddddd;
        }
    </style>
</head>
<body>
<table>
    <thead>
        <tr>
            <th>User Name</th>
            <th>Game Name</th>
            <th>Score</th>
            <th>Review Text</th>
        </tr>
    </thead>
    <tbody>
    <!-- We want to repeat this for each game in the database -->
    <% for (const result of results) { %>
        <tr>
            <td><%= result.userName %></td>
            <td><%= result.gameName %></td>
            <td><%= result.score %></td>
            <td><%= result.reviewText %></td>
        </tr>
    <% } %>
    <!-- End repeating bit -->
    </tbody>
</table>
<form action="/add-review" method="get">
    <input type="submit" value="Add a Review!">
</form>
<form action="/logout" method="get">
    <input type="submit" value="Log Out!">
</form>
</body>
</html>
```

Let's modify our `index.html` into `add-review.ejs`

in `/views/add-review.ejs`

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Reviews</title>
</head>
<body>
    <form action="/submit" method="post">
        <label for="gameName">Game Name</label>
        <input type="text" name="gameName" id="gameName">
        <br>
        <label for="score">Score</label>
        <input type="text" name="score" id="score">
        <br>
        <label for="reviewText">Review Text</label>
        <input type="text" name="reviewText" id="reviewText">
        <input type="submit" value="submit">
    </form>
</body>
</html>
```

Let's add a new register and sign up page, `index.html`

```html
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register or Log In</title>
</head>

<body class="text-center">

    <form class="form-signin" action="/register" method="POST">
        <h1>Register</h1>
        <label for="inputEmail">Email address</label>
        <input type="email" id="inputEmail" class="form-control" placeholder="Email address" required autofocus name="username">
        <label for="inputPassword">Password</label>
        <input type="password" id="inputPassword" class="form-control" placeholder="Password" required name="password">
        <button class="btn btn-lg btn-primary btn-block" type="submit">Register</button>
    </form>

    <form class="form-signin" action="/login" method="POST">
        <h1>Sign in</h1>
        <label for="inputEmail">Email address</label>
        <input type="email" id="inputEmail" class="form-control" placeholder="Email address" required autofocus name="username">
        <label for="inputPassword">Password</label>
        <input type="password" id="inputPassword" class="form-control" placeholder="Password" required name="password">
        <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
    </form>
</body>

</html>
```

And finally, our `app.js`

```javascript
const express  = require( "express" );
const mongoose = require( "mongoose" );

// 1. Require dependencies /////////////////////////////////////////
//Your code here!
////////////////////////////////////////////////////////////////////

// this is a canonical alias to make your life easier, like jQuery to $.
const app = express(); 
// a common localhost test port
const port = 3000; 

// body-parser is now built into express!
app.use( express.urlencoded( { extended: true} ) ); 

// 2. Create a session. The secret is used to sign the session ID.
//Your code here!
////////////////////////////////////////////////////////////////////


app.set( "view engine", "ejs" );

// connect to mongoose on port 27017
mongoose.connect( 'mongodb://localhost:27017/games', 
                 { useNewUrlParser: true, useUnifiedTopology: true });

// 3. Create the userSchema ////////////////////////////////////////
//Your code here!
////////////////////////////////////////////////////////////////////

const gameSchema = new mongoose.Schema({
    userName: String,
    gameName: String,
    score: Number,
    reviewText: String
});

const Game = mongoose.model( "Game", gameSchema );


// 4. Add our strategy for using Passport, using the local user from MongoDB
//Your code here!
////////////////////////////////////////////////////////////////////

// Simple server operation
app.listen ( port, () => {
    // template literal
    console.log ( `Server is running on http://localhost:${port}` );
});

// 5. Register a user with the following code, which needs to be in the appropriate route
//Your code here!
////////////////////////////////////////////////////////////////////

// 6. Log in users on the login route //////////////////////////////
//Your code here!
////////////////////////////////////////////////////////////////////

app.get( "/", ( req, res ) => {
    console.log( "A user is accessing the root route using get" );
    res.sendFile( __dirname + "/index.html" );
});

// 7. Register get routes for reviews and add-review ///////////////
//Your code will replace this section!
app.get( "/reviews", async( req, res ) => {
    console.log( "A user is accessing the reviews route using get, and found:" );
    try {
        const results = await Game.find();
        console.log( results );
        res.render( "reviews", { results : results });
    } catch ( error ) {
        console.log( error );
    }
});

app.get( "/add-review", ( req, res ) => {
    console.log( "A user is accessing the add-review route using get" );
    res.render( "add-review" );
});
////////////////////////////////////////////////////////////////////

// 8. Logout ///////////////////////////////////////////////////////
//Your code here!
////////////////////////////////////////////////////////////////////

// 9. Submit a post to the database ////////////////////////////////
//Your code here!
////////////////////////////////////////////////////////////////////
```

And set up our requirements with:
```
npm init
npm i express ejs mongoose
```

Make sure `mongod` is running! 

### Required packages

We are going to install the following packages:

- `passport` - An authentication middleware for express making use of different strategies
- `passport-local` - A username and password authentication strategy
- `passport-local-mongoose` - Simplifies using username/password with Mongo
- `express-session` (not express-sessions) -Middleware for creating sessions.

```
npm i passport passport-local passport-local-mongoose express-session dotenv
```

Note: It's very important to use these snippets in the order they are used in this example. I have thus included locations in the sample code for where to insert each bit by number!

### Add needed packages:

```javascript
// 1. Require dependencies /////////////////////////////////////////
const session = require("express-session")
const passport = require("passport")
const passportLocalMongoose = require("passport-local-mongoose")
require("dotenv").config();
////////////////////////////////////////////////////////////////////
```

We don't need  to directly user passport-local, so don't need access to it through a const

### Set up the dotenv file

Create and add the following to the `/.env` file:

```
SECRET=Something secret to encrypt our session
```

### Use session

```javascript
// 2. Create a session. The secret is used to sign the session ID.
app.use(session({
    secret: process.env.SECRET,
    resave: false,
    saveUninitialized: false
}));

app.use (passport.initialize());
app.use (passport.session());
////////////////////////////////////////////////////////////////////
```

### Create the userSchema

We need to use a specific schema for passport-local-mongoose, make sure your fields are named as follows:

```javascript
// 3. Create the userSchema /////////////////////////////////////////
// It is important not to change these names
// passport-local-mongoose expects these. Use `username` and `password`!
const userSchema = new mongoose.Schema ({
    username: String,
    password: String
})

// plugins extend Schema functionality
userSchema.plugin(passportLocalMongoose);

const User = new mongoose.model("User", userSchema);
////////////////////////////////////////////////////////////////////
```

### Set our Passport strategy:

This section creates the Passport strategy, and encodes our user into the session. 
passportLocalMongoose, which we plugged in earlier, is doing the heavy lifting for us.

```javascript
// 4. Add our strategy for using Passport, using the local user from MongoDB
passport.use(User.createStrategy());

passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());
////////////////////////////////////////////////////////////////////
```

### Register users:

Add the following snippet to register users.

Note the weird syntax on `passport.authenticate`. This is a higher-order function which returns a function, (i.e. a function factory,) the second set of args are passed to the returned function.

```javascript
// 5. Register a user with the following code, which needs to be in the appropriate route
// As in (3), be sure to use req.body.username and req.body.password, and ensure the 
// html forms match these values as well
app.post( "/register", (req, res) => {
    console.log( "User " + req.body.username + " is attempting to register" );
    User.register({ username : req.body.username }, 
                    req.body.password, 
                    ( err, user ) => {
        if ( err ) {
        console.log( err );
            res.redirect( "/" );
        } else {
            passport.authenticate( "local" )( req, res, () => {
                res.redirect( "/reviews" );
            });
        }
    });
});
////////////////////////////////////////////////////////////////////
```

Once signed in, we can get the username with:

```javascript
req.user.username
```

### Log-in Users:

Logging in users is similar to registering users...

```javascript
// 6. Log in users on the login route ////////////////////////////////
app.post( "/login", ( req, res ) => {
    console.log( "User " + req.body.username + " is attempting to log in" );
    const user = new User ({
        username: req.body.username,
        password: req.body.password
    });
    req.login ( user, ( err ) => {
        if ( err ) {
            console.log( err );
            res.redirect( "/" );
        } else {
            passport.authenticate( "local" )( req, res, () => {
                res.redirect( "/reviews" ); 
            });
        }
    });
});
////////////////////////////////////////////////////////////////////
```

### Allow in authenticated users

Only users who are authenticated should be able to access the `reviews` page. Ditto for the `add-review` page

```javascript
// 7. Register get routes for reviews and add-review ////////////////
app.get( "/reviews", async( req, res ) => {
    console.log("A user is accessing the reviews route using get, and...");
    if ( req.isAuthenticated() ){
        try {
            console.log( "was authorized and found:" );
            const results = await Game.find();
            console.log( results );
            res.render( "reviews", { results : results });
        } catch ( error ) {
            console.log( error );
        }
    } else {
        console.log( "was not authorized." );
        res.redirect( "/" );
    }
});

app.get( "/add-review", ( req, res ) => {
    console.log( "A user is accessing the add-review page, and..." );
    if (req.isAuthenticated()) {
        console.log( "was authorized" );
        res.render( "add-review" );
    } else {
        console.log( "was not authorized" );
        res.redirect( "/" ) 
    }
});
////////////////////////////////////////////////////////////////////
```

### Log-out Users:

We can log out users on the logout route with the following
```javascript
// 8. Logout ///////////////////////////////////////////////////////
app.get( "/logout", ( req, res ) => {
    console.log( "A user is logging out" );
    req.logout();
    res.redirect("/");
});
////////////////////////////////////////////////////////////////////
```

### Using the session when posting reviews:

Finally, lets complete our application by by adding in the submit route:

```javascript
// 9. Submit a post to the database ////////////////////////////////
// Note that in the username, we are using the username from the
// session rather than the form
app.post( "/submit", async( req, res ) => {
    console.log( "User " + req.user.username + " is adding the review:" );
    console.log( req.body )
    const game = new Game({
        userName:   req.user.username,
        gameName:   req.body.gameName,
        score:      parseInt( req.body.score ),
        reviewText: req.body.reviewText
    });

    game.save();

    res.redirect( "/reviews" );
});
////////////////////////////////////////////////////////////////////
```

Note, when you restart your server (which nodemon does frequently!) all of the cookies expire, so you will need to log in again.

## Lab Assignment

For the final big assignment, you will add complete database integration into the application from Lab 7. You finally have a stack which is ready for a production environment!

### Schema

Update you Schemas from Lab 8, if needed, to work with Passport / Mongoose

### User registration and login:

Modify the login page on the "/" route.

Link the login form to the "/login" route with POST. In this route perform the following:
  - Using passport, log in and authenticate the user
  - If authentication fails, redirect back to "/"
  - If registration succeeds, redirect to "/todo"

Link the register form to the "/register" route. In this route perform the following:
  - Register a new user using passport
  - If registration fails, redirect back to "/"
  - If registration succeed, redirect to "/todo"
  - The Authentication key, which is checked against when registering users, should be stored in the `.env` file!
  
`todo` should only be available to Authenticated users. 
- As long as user is authenticated, they should be able to return to "/todo" without logging in again, until the cookie expires or they log out.

### To-do list display

Use EJS to render the to-do list on the `/todo` route

- Modify your code from Lab 7 to instead read from the database. 

- Reuse as much code as possible! The front-end should have minimal to no changes.

### To-do list functionality

Modify the code from Lab 7 to use the database. 
- All of the same functionality should exist, 
  - Now all operations should read and write to the database instead read from the database rather than the JSON file

### Submission

Please submit to URCourses by the due date!

### Aside: The Next Steps

If Full-Stack Web Dev has won you over as your dream job, in my opinion, the most important things we did not cover in this lab are:

- A modern View engine, such as [React](https://reactjs.org/), [Angular](https://angular.io/) or [Vue.js](https://vuejs.org/)

- Better JavaScript with [TypeScript](https://www.typescriptlang.org/)

- Having your Browser-side JavaScript talk directly to the Server-side Node.js, e.g. with AJAX, or with the Fetch API
  - With this you could link up Labs 5 and 9 to create a site which updates on demand without refreshing the page!
  - With this, if our to-do list app was live, we could periodically check if other users had added new data, and if so automatically update our site using the DOM
  - This is how infinite scroll websites fetch data without reloading the page!

An example of how this would work with AJAX [found on StackOverflow](https://stackoverflow.com/questions/53897250/how-to-call-a-server-side-nodejs-function-using-client-side-javascript)

In Node.js with Express:
```javascript
app.get('/hello', function(req, res) {
    // Your function to be called goes here.
    res.send({ data: "hello" })
});
```

In JavaScript using jQuery:
```javascript
$.ajax({
        type: 'GET',
        url: '/hello',
        success: function(response) { 
        console.log(response);
    },
    error: function(xhr, status, err) {
        console.log(xhr.responseText);
    }
});
```

- Level up our MVC / Model with a [REST API](https://www.redhat.com/en/topics/api/what-is-a-rest-api)