---
layout: default
title: ENSE 374 Lab 4
---

# Lab 4: JavaScript and DOM

ENSE 374 - Software Engineering Management - Laboratory

University of Regina - Engineering and Applied Science - Software Systems Engineering

Lab Instructor: [Adam Tilson](mailto:Adam.Tilson@uregina.ca)

---

## Objective

This lab introduces JavaScript (JS) which is a programming language which runs in the Web Browser. In addition to being able to perform typical programming language tasks, like data storage and computation, it can additionally interact with the HTML and CSS on a web page through the Document Object Model (DOM), allowing real time interactions with the page performed on the client side. We'll look at the capabilities of JavaScript in this lab.

## Equipment

Computer running Windows, MacOS or Linux, with an Intel or AMD-based processor (x86 or x86-64) with administrator privileges. 
- A modern web browser, with a strong preference for Firefox or Chrome
- A text editor, preferably VS Code

## Part 1: Introduction to JavaScript

### What is JavaScript

- A language designed to give your browsers autonomy so they do not need to communicate with the server for trivial operations
- Today a standard (ECMAscript) which browsers need to implement
- Interpreted, not compiled

### Hello JavaScript World

- Open the Dev console (F12)
```javascript
alert("Hello World");
console.log("Hello World");
```

### Locations for JS in HTML

Inline (in a tag):

```javascript
<a onclick="alert('hello');" href="#">Pop Up</a>
```

Internal:

```javascript
<script type="text/javascript">alert("hello")</script>
```

External:

```javascript
<script src="index.js" charset="utf-8"></script>
```

*Always link the external page as the last element in the `<body>` tag, this is to ensure necessary HTML elements are loaded before the script executes*

### Learning and Mastering Javascript

[MDN - JavaScript](https://developer.mozilla.org/en-US/docs/Web/JavaScript)
JavaScript The Good Parts [Read for Free on O'Reilly Higher Education](https://uregina.libguides.com/az.php?q=o%27reilly)

### White Space

- C-style, mostly optional, but recommended for readability
- [Style Guide](https://github.com/rwaldron/idiomatic.js)

### Comments

```javascript
// line style
/* block comments */
```
*Wrong, obsolete and obvious comments are worse than none!*
**Strive for self-documenting code through good variable and method names and logical control structures**

### Creating / Assigning Variables

Block scoped variable:

```javascript
let daysThisMonth = 30;
```
Once constants are set they cannot be changed:

```javascript
const cmPerInch = 2.54;
```

Globally scoped variables should be avoided where possible:

```javascript
var phrase = "Pretend I don't exist";
```

Type is inferred from the literal, and it can change later on
- If you want more rigorous typing, TypeScript is a JavaScript extension which imposes additional rules on the language during development, but compiles back to vanilla JavaScript. 

### Variable Names

- letter followed by letters, digits, underscores.
  - no spaces (as in all programming languages!)
- [no reserved words allowed!](https://www.w3schools.com/js/js_reserved.asp)
- camelCase is preferred

### Primitives

- numbers, strings, booleans
- `null` - intentional absence of a value, assigned by _you_.
- `undefined` - unintentional absence of a value. Returned by JS if you forgot to assign something

### Numbers

All numbers are 64-bit floats (double). 
- `1e2` means `100`
- `-37`
- `NaN` means Not a Number, e.g. a 0/0 error.
- `Infinity` exists if the magnitude of a number is huge (>310 0's). 
  - Also returned by div/0 errors. 
  - Signed.
- `-0` is legal.
- There are methods for numbers, e.g. `Math.floor(number)`
- Math object defines common methods, e.g. `Math.pow(...)`, `Math.abs(...)`, `Math.floor(...)`, `Math.random(...)`
- `+`, `-`, `+=`, `-=`, `++`, `--` all work as expected

Number type built in functions:
```javascript
number.toExponential()
number.toFixed(totalDigits)
number.toPrecision(decimalPoints)
number.toString(base)
```

### Strings
- Single `'` or double `"` quotes
  - Double is preferred most of the time
- Zero or more characters
- `\` used as an escape character: `\\`, `\'`, `\"`, `\n`, and others
- No char type, only length one strings
- `length` property. 
```javascript
>> "word".length
4
```
- Strings are immutable - once made they can't be changed directly
- `+` for concatenation
- Strings have methods, e.g. `toUpperCase()`

```javascript
>> "word".toUpperCase()
"WORD"
>> "WORD".toLowerCase()
"word"
```

- If your strings needs to include one type of quotes as a character in the string, you can use the other to delimit the string, e.g. `"He said 'hi' "` or `'They said "see ya later!" '`
  - This can be more convenient than escaping
- Positions are indexed, like in arrays (but are read only!)

Template Literals 
- strings declared surrounded by the backtick character: e.g. :\`
```javascript
`I counted ${ 3 + 5 } apples` 
```
  - Any JS in the `${ }`'s is evaluated.
  - If you want the '$' in the string, do '$$'.

`parseInt` and `parseFloat` extracts the leading number from a string until it something non numeric.

`slice` lets you extract substrings

```javascript
>> let name = "Robot"
>> name.slice(1,4)
`obo`
```

Some more useful built-in functions...

```javascript
string.charAt(pos)
string.charCodeAt(pos)
string.concat(string...)
string.indexOf(searchString, pos)
string.lastIndxOf(searchString, pos)
string.match(regexp)
string.replace(searchValue, replaceValue)
string.search(regexp)
string.slice(start,end)   - like substr
string.split(separator, limit)
string.substring(start, end)
string.toLowerCase()
string.toUpperCase()
string.trim()
String.fromCharCode(char...)
```

Can cascade methods, e.g. `string.trim().toUpperCase()`

### Booleans

- Values that represent False: `false`, `null`, `undefined`, `""`, `0`, `NaN`
  - Everything else represents `true`
- Testing equality: always use `===` (also tests type)
- `!` toggles truthiness

### Infix Operators
By precedence:

- `*`, `/`, `%`  (modulo), `**` (power).
- `+`, `-` 
- `>=`, `<=`, `>`, `<`
- `===`, `!==`
- `||`, `&&`
- override precedence with `( )`'s 

*Technically `==` exists in JavaScript, you should pretend it doesn't.

### Typeof

- A prefix operator, not a function:
```javascript
typeof x
```
- returns the type of a variable: 
  - `number`
  - `string`
  - `boolean`
  - `undefined`
  - `function`
  - `object` 
- arrays and null types map to objects

## Part 2: Statements and Control Structures

### Statements

Types:
- expression
- disruptive (`break`, `return`, `throw`)
- condition (`if`, `try`, `switch`)
- loop (`for`, `do`, `while`)

Mostly work as expected in c++, exceptions:
  - e.g. switch "cases" do not need to be const's.

If you like syntax diagrams, JavaScript the Good Parts will show you what you need.

e.g., here's one on whitespace

![](res/whitespace-syntax-diagram.png)

Source: JavaScript The Good Parts. Douglas Crockford. 2008.

### Conditions

In JavaScript, `if...else if...else` and `switch-case` exist: 

Example from [W3Schools JS If Else ElseIf](https://www.w3schools.com/js/js_if_else.asp)
```javascript
if ( time < 10 ) {
  greeting = "Good morning";
} else if ( time < 20 ) {
  greeting = "Good day";
} else {
  greeting = "Good evening";
}
```

Example from [W3Schools JS Switch](https://www.w3schools.com/js/js_switch.asp)
```javascript
switch (new Date().getDay()) {
  case 1:
    day = "Monday";
    break;
  case 2:
     day = "Tuesday";
    break;
  case 3:
    day = "Wednesday";
    break;
  case 4:
    day = "Thursday";
    break;
  case 5:
    day = "Friday";
    break;
  default:
    day = "Weekend";
}
```

- Cases can be any type
- Fall-through will occur until a `break` is encountered

### Loops

There are several types of `for` loops:

[Examples from W3Schools JS Loop For](https://www.w3schools.com/js/js_loop_for.asp)

```javascript
for (let i = 0; i < 5; i++) {
  text += "The number is " + i + "<br>";
}
```

`for...in` loops through properties of an object:

[Examples from W3Schools JS Loop For In](https://www.w3schools.com/js/js_loop_forin.asp)

```javascript
const person = {fname:"John", lname:"Doe", age:25};

let text = "";
for (let x in person) {
  text += person[x];
} 
```

`for...of` loops through iterables data structures:

[Example from W3Schools JS Loop For Of](https://www.w3schools.com/js/js_loop_forof.asp)

```javascript
const cars = ["BMW", "Volvo", "Mini"];

let text = "";
for (let x of cars) {
  text += x;
}
```

There are also `while` loops:

[Example from W3Schools Loop While](https://www.w3schools.com/js/js_loop_while.asp)

```javascript
while (i < 10) {
  text += "The number is " + i;
  i++;
}
```

And `do...while` loops:

[Example from W3Schools Loop While](https://www.w3schools.com/js/js_loop_while.asp)

```javascript
do {
  text += "The number is " + i;
  i++;
}
while (i < 10); 
```

### Try Throw Catches

An additional control structure for running risky code and catching errors is the `try-throw-catch`

[Example from W3School JS Errors](https://www.w3schools.com/js/js_errors.asp)

```javascript
function myFunction() {
  const message = document.getElementById("p01");
  message.innerHTML = "";
  let x = document.getElementById("demo").value;
  try {
    // block for risky code to try
    if(x == "") throw "is empty";
    if(isNaN(x)) throw "is not a number";
    x = Number(x);
    if(x > 10) throw "is too high";
    if(x < 5) throw "is too low";
  }
  catch(err) {
    // runs if an error occurs
    message.innerHTML = "Error: " + err + ".";
  }
  finally {
    // always runs regardless of try/catch result
    document.getElementById("demo").value = "";
  }
} 
```

## Part 3: Objects

### Objects

- Similar to C++ classes
- Collections of key-value pairs.
- Can be nested
- Ad-hoc or prototyped
- No guarantee they will have all of the expected properties - test first!
- First we'll look at ad-hoc objects - these are both declared and instantiated on the fly

### Creating Objects

```javascript
// string style keys
var personString = {
    "first-name" : "Adam",
    "last-name" : "Tilson"
}

// name style keys
var personName = {
    firstName : "Adam",
    lastName : "Tilson"
}
```

### Reading Objects

```javascript
//string style lookup
personString["first-name"];
//name style lookup
personName.firstName;
```

- If a value doesn't exist, it returns undefined
- Can use `||` to fill in a default, eg. `personName.firstName || "Adam"`
- If you need to retrieve from a nested obj, make sure it exists first:
  - `adam.schedule` && `adam.schedule.morning`
- if you want to see all of the contents of an object in the console use: `console.dir(myObject)`

### Updating Objects

- Use the assignment operator,
  
```javascript
personString["first-name"] = "A";
personName.firstName = "A";
```

Objects are passed by reference, not copied

### Deleting Objects

```javascript
delete personString["first-name"];
```

### Prototyping

You can link an object to a prototype to inherit properties. This is like in C++ where you must first define a class before you can create an instance of it.
This allows you to use a constructor:

```javascript
function Person(first, last, age, eyeColor) {
    this.firstName = first;
    this.lastName = last;
    this.age = age;
    this.eyeColor = eyeColor;
}

var myFather = new Person("John", "Doe", 50, "blue");
var myMother = new Person("Sally", "Rally", 48, "green");
```

We can modify the prototype later by adding a new prototype with a default value:

```javascript
Person.prototype.nationality = "English";
```

Add a function later

```javascript
Person.prototype.name = function() {
    return this.firstName + " " + this.lastName;
};
```

Rule: you can modify your own prototypes, but probably shouldn't modify others'!

### Arrays

Arrays are simply objects that allow using ints for the names. 
- They also have some shortcuts and built in methods to make them operate like arrays do in other languages.

```javascript
let x = [1, 2, 3];
let x = []
let x = ["one", "two", "three"] - associative arrays
```

- length property
  
```javascript
>> x.length;
3
```

Two ways to append a value to the end of the list:

```javascript
x[x.length] = 6   
x.push(6)
```

- Deleting values leaves holes in the array 
    - Rather than deleting, you can splice instead
e.g. start at 2 element, delete 1, and splice the two sub arrays together: 

```javascript
x.splice(2,1)
```

- No 2d support out of the box, but you can make an array of arrays.

Array class methods:

```javascript
array.concat (item, ...)
array.join (separator) - make a string from an array
array.pop()
array.push(item, ...)
array.reverse()
array.shift() - like pop but for the first element
array.slice(start, end) - copy a portion of an array
array.sort(compareFunction)
array.splice(start, count)
array.unshift(item, ...) - push front
```

## Part 4: Functions

A simple addition function:

```javascript
function add (x, y) {
    return x + y;
}
```

Note: `function` keyword, and no explicitly defined argument or return types

### Anonymous Functions

Functions can be created anonymously as expressions.

In this case we can assign these to variables, however, we'll see later how we can also declare these functions directly from their parameter list of other functions as callbacks.

```javascript
let add = function (x, y) {
    return x + y;
}
```

Or using the popular arrow syntax:

```javascript
let add = (x, y) => {
    return x + y;
}
```

or even as a one-liner, but this is a bit difficult...

```javascript
let add = (x, y) => x + y;
```

[Arrow functions have a few syntax options](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Functions/Arrow_functions)

In JavaScript functions are objects, so they can be stored in variables or passed as parameters!

### Calling Functions

```javascript
add (3, 4)
```

The implicit `arguments` array contains all of the arguments, even unnamed ones. e.g.:

```javascript
var sum = function () {
    var i, sum = 0;
    for ( i = 0; i < arguments.length; i += 1 ) {
        sum += arguments[i];
    }
    return sum;
};
```

### Scope

When we use the `var` keyword for variables, we have function scope, not block scope.

We should use the `let` keyword instead!

```javascript
var outer = function () {
    var a = 3, b = 5;
    // At this point, a is 3, b is 5, and c is not defined
    console.log(a);
    console.log(b);
    console.log("c is not defined");
        var inner = function () {
        var b = 7, c = 11;
        // At this point, a is 3, b is 7, and c is 11
        console.log(a);
        console.log(b);
        console.log(c);
        a += b + c;
       // At this point, a is 21, b is 7, and c is 11
        console.log(a);
        console.log(b);
        console.log(c);
     };
    inner ();
    // At this point, a is 21, b is 5, and c is not defined
    console.log(a);
    console.log(b);
    console.log("c is not defined");
};

outer();
};
```

This is basically awful, so we should instead use `let`!

A scope search happens where JS looks for the variable in local scope first, if not it will fall back to parent block scope, e.g. in nested functions, then grandparent, etc.

### High order functions and callbacks

A high order function is a function which takes a function as an argument, or returns a function:

Or a function expression:
```javascript
var hello = function () {
    console.log("Hello");
}
```

A simple example: call twice:

```javascript
function callTwice(func) {
    func()
    func()
}
```

When we pass a function in here
- don't include the ()'s, 
- that is, we want to pass a reference to function
- we don't want to run the function and pass in its return value

We can also have a function which returns a function. This is like a function factory:

```javascript
function getAFunction () {
    return function () {
        console.log("Hello")
    }
}
```

Here's how we can use that factory:

```javascript
function makeBetweenFunc (x, y) {
    return function(num) {
        return num >= x && num <= y;
    }
}
isItNiceOutside = makeBetweenFunc(20, 30);
```

We sometimes need to invoke anonymous functions:

The following JavaScript built in function calls a function passed as an argument after 5000 ms:

```javascript
setTimeout (func, 5000)
```

We can also define the callback function directly in the argument list:

```javascript
setTimeout (function() {
    alert("Welcome")
}, 5000)
```

Callbacks are extremely useful, and we'll see them a lot when working with both UI operations and Node.js in a few weeks.

## Part 5: DOM

### DOM Overview

The document object model (DOM) catalogs the elements of a webpage into JavaScript objects which you can manipulate, namely HTML and CSS. 
  - We can also listen to user interactions (Events) and respond to them.
  - All of the HTML Attributes exist in the JS object, not only the ones we manually define through HTML Code. 
    - You can read it with `dir`

### Single Responsibility

We will learn how to change individual CSS values in JS. 
  - Should we? No! 
  - Recall, all of our styles should be defined in CSS style sheets, e.g. using classes
  - Instead, you could attach or detach classes in JS, which will update the styles

### What you need to know for this lab?

You don't need to memorize all of the syntax (We'll use JQuery next week which simplifies the syntax)

Instead, spend more time learning what you can do, more than specifically how you do it.

### Waiting for user interactions

We can attach event listeners, which wait for a user to do an action, and then call a function when a user does that action

```javascript
btnObj.addEventListener("mouseover", function () {
alert("hi");
});
```

### Small Example - LogoSwap Cube Firefox

In Firefox, on the start page, we have the FireFox Logo on the page
- Find the Class using the inspector
- ".logo" is the class name
  - The image is being set using the "background" property
  - We could find a replacement, say... `https://i.redd.it/11nzhiq68x631.png`
- In our JavaScript console...

```javascript
let img = document.querySelector(".logo");
img.style.backgroundImage = "url(https://i.redd.it/11nzhiq68x631.png)";
img.style.backgroundRepeat = "repeat";
img.style.backgroundPosition = "0px 3px"; 
img.style.border = "2px solid magenta"; //neon vibes
img.style.borderRadius = "5px";
let logoText = document.querySelector(".wordmark");
logoText.parentElement.removeChild(logoText);
```

### The Root of the DOM: The Document object

You can learn more about the document object using the: 

```javascript
console.dir(document)
```

You can also do this with individual elements.

### Selecting and element from the DOM

Some commands for selecting elements from the DOM are:

```javascript
getElementById("hero-image") //(returns an HTMLElement)
getElementsByTagName("h1") //(returns HTMLCollection, like an Array)
getElementsByClassName("header") //(Also returns HTMLCollection)
```

- The returned elements is a JavaScript object representing a chunk of HTML. 
- If you store it in a variable, e.g. `const img`. 
  - Then you will have an object you can use. Using the CRUD principles we discussed, you can manipulate it!
- HTML objects have prototypes, eg. `HTMLImageElement`

- If you call any of these getElementBy...() functions on an HTML element, the returned objects will be from the HTML element's children, rather than the documents children.

### HTMLCollections

You can use array access `[]` and `.length`, that's likely all you'll need.

```javascript
let inputs = document.getElementsByTagName("input")
for (let input of inputs) { 
  console.log(input.value);
};
```

### querySelector

- The newer, best selector by far
- Pass in a CSS-style selector, using the same syntax as in CSS
- `querySelector` returns 1, `querySelectorAll` returns all.
  
```javascript
const img = document.querySelector("#my-image");
```
- can even use the advanced CSS Selection rules like `ul li.second` for the `li` with class `second` that is a child of a `ul`


### querySelectorAll

returns a nodelist. 
- Like an HTML collection, but slightly different.
- has a `.length`, array access, `[]`, and `forEach`.

### CSS Attribute Selector

If you need to target a specific type of input...

```javascript
document.querySelector("input[type='password']")
```

### Most important DOM properties and methods:

```javascript
element.classList
element.getAttribute()
element.setAttribute()
element.appendChild()
element.append()
element.prepend()
element.removeChild()
element.remove()
element.createElement
element.innerText
element.textContent
element.innerHTML
element.value
element.parentElement
element.children
element.nextElementSibling
element.previousElementSibling
element.style
```

### innerText and textContent

- `innerText` is the text that's in the tags. `<p>This is the The inner Text</p>`.
- If there are multiple things inside with text, get all the text.
- You can even call it on the body
- If you change it, it will drop all children, and overwrite it with just text

- `textContent` includes internal spacing, stuff that isn't rendered on the page but is part of the document. 
  - Less likely to use this one.

### innerHTML

- similar to `innerText`, but returns all of the contained content as HTML as a string. 
  - You can read and modify it as needed.
  - However, you need to add things as string
    - Generally DOM manipulation is preferred
- `innerHTML` parses tags, vs. `innerText` would not parse them as tags.

### Attributes such as value, src and href

We can access attributes as properties of the object
e.g. `.value`, `.checked`, `.placeholder` 
Many of these can be easily accessed. However, not all!

### Getters and Setters for less accessible attributes

`getAttribute`, `setAttribute`

e.g. `getAttribute('max')`
e.g. `setAttribute('max', 1000)`

you can even change type attribute, e.g. for form elements

```javascript
document.querySelector("a").attributes;
document.querySelector("a").getAttribute("href");
document.querySelector("a").setAttribute("href", "https://www.w3schools.com");
```

### Traversing the DOM

If you've selected an element but want the next one, or child inside, what do you do?
`parentElement` property gets the parent (Only one)
`children` - returns an HTMLCollection element. (Many)
`nextElementSibling` and `previousElementSibling` get the next or previous sibling, respectively.

### Creating Elements

```javascript
let h1 = document.createElement('h1')
```

- From here you can add whatever you want, classes, attributes, etc.

```javascript
h1.innerText = "A new heading!"
```

- Then you just need to add it to the DOM somewhere
- separately find the parent you would like to attach it to...

```javascript
let parent = document.findElementById("my-div");
```

  - `parent.appendChild(h1)`, appends it as the last child of the element
  - `parent.prependChild(h1)`, prepends it as the first child of the element
  - `insertBerfore(newNode, existingNode)` allows insertion at a specific point

precise positioning with insertAdjacentElement

```javascript
let div = document.createElement("div");
let span = document.createElement("span");
div.appendChild(span)
let newSpan = document.createElement("span");
div.insertBefore(newSpan, span);
```

### Removing

remove, removeChild

`self.remove ()`
or 
`parent.removeChild(element)`


## Part 6: Setting styles through CSS

### Changing styles

Changing styles from the DOM is legal, but weird and generally no preferred

- use the style property
- conceptually "write-only" because it only reads inline styles
  - this is bad practice.

- Because "-" is not allowed in JavaScript identifiers, we switch from css-style `kebab-case` to JavaScript style `camelCase`.

e.g. `font-family` becomes `fontFamily`

All of the properties must be assigned as strings, eg. "30px", "30%", "3rem"

### Finding the Computed Style

```javascript
getComputedStyle(element)
```

- returns an object-like structure with key-value pairs for all the CSS properties. 
- Many value will be default.

### Changing class with classList

A better way to change styles, particularly if there are many changes is to just define different classes in your external CSS which are not linked to any objects, and then use JavaScript to attach those classes.

classList returns a DOMTokenList object in which you can add elements easy enough

- functions: 

```javascript
classList.remove('classname')
classList.add ('classname')
classList.toggle('classname')
```
- With toggle, if the class is not there, add it. If it is there, remove it.

## Part 7: DOM Events

### Events

A small set of events we can manage: 
- clicks 
- drags
- drops
- hovers
- scrolls
- form fill
- form submit
- focus or blur
- key presses
- double click
- screen resize
- audio
- animation

Check out the [MDN event reference](https://developer.mozilla.org/en-US/docs/Web/Events)!

Events link an element, a user interaction, and a response (function)

### Adding Events

Bad ways to register that you will likely see in examples, including mine:

- in the html tag  

```html
<a href="#" onclick="alert('hi')">Click Me</a>
```

Also not recommended, in JavaScript...

```javascript
let button = document.getElementById("my-button");
button.onclick = function () { ... }
```

The good way to register:

```javascript
let button = document.getElementById("my-button");
button.addEventListener("click", function () { ... } );
```

The last method is universal, consistent between different types of events, and also uses callback syntax for declaring the function.

### Event objects

Invoking an event sometimes creates an object which has more info about that event, eg. your mouse location, screen location, modifiers, etc.
This is passed as the first arg of the callback, typically given the variable "e"

### keydown, keyup, keypress

`keydown` and `keyup` fire on rising or falling edges for any key on the keyboard. 
  - `keypress` only fires once per rising edge and falling edge
  - Both `keydown` and `keypress` are subject to keyboard repeat
- If you want to process an `enter` in a textbox, do a keypress event, look inside the event `e` to see if `enter` was pressed, and if so, then execute code
- If you want to only register one key press, avoiding keyboard repetition, set a flag variable on the `keydown` even, clear it on the `keyup` event, and use the flag variable to update your code.
- 
Example from [MDN Keypress Event](https://developer.mozilla.org/en-US/docs/Web/API/Document/keypress_event)

```javascript
const log = document.getElementById('log');

document.addEventListener('keypress', function (e) {
  log.textContent += ` ${e.code}`;
});
```

### Bubbling

When a click input is captured, it registers on the targeted element, then bubbles up through all the parent elements.

[Example from JavaScript.info Bubbling and Capturing](https://javascript.info/bubbling-and-capturing)

```html
<style>
  body * {
    margin: 10px;
    border: 1px solid blue;
  }
</style>

<form onclick="alert('form')">FORM
  <div onclick="alert('div')">DIV
    <p onclick="alert('p')">P</p>
  </div>
</form>
```

If you need to, you can use `event.stopPropagation()` to halt the bubbling process prematurely. Just be careful this doesn't break other expected functionality - in other words, bubbling in JavaScript / DOM is an intended feature, not a bug, so you should have a good reason for disabling it!

## Lab Assignment

We're going to take a break from our main project for now - we'll get back to that in the next lab. But this lab should help.

For this lab, we're going to implement a sorted list form. Original, I know!

The purpose is to get you used to finding and modifying DOM elements with JavaScript.

Depending on your comfort with JavaScript, there are three version you may attempt:

### Version 1

There are five fixed text boxes, a text box and a button used to add elements, and a textbox used to sort
- I'm using a style similar to the previous assignment. You should have completed this and get this style basically for free:

![](res/sorta-easy-1.png)

In version 1 you can add elements to the list. 
- There is a static length of the list, 5, 
- when more than 5 items are added, start back at the top overwriting elements. 
- You can also sort the elements

Adding words:

![](res/sorta-easy-1-filling-in.png)

### Version 2

In V2, there is no length to the list. You can add as many elements as you like and sort them.
- The list will start empty

![](res/sorta-easy-2-blank.png)

- When you add an element it appears in the list

![](res/sorta-easy-2-add.png)

- regardless of the length of the list, sort works as expected

![](res/sorta-easy-2-sort.png)

- adding more elements just pushes them to the bottom of the list

### Version 3

- The final version work as in V2, but when you sort the list items, the text boxes should fade out for 1 second, and then move in an animated way to show them being reordered.
- You may want to look into: The Set Interval CallBack
  - The CSS Transition Property, as well as modifying Opacity through JavaScript 

### Submission

You may complete any of the versions. 
- The things you learn will be directly applicable to the next hand-in assignment. 
- Your progress will be checked by a demo next week! Good Luck.