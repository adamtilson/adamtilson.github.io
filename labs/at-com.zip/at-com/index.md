---
# Feel free to add content and custom Front Matter to this file.
# To modify the layout, see https://jekyllrb.com/docs/themes/#overriding-theme-defaults

layout: default
---

# Adam Tilson's GitHub Pages Site

Welcome. This site acts as a demonstration for students about the types of sites that can be hosted on GitHub pages to act as a portfolio. I will be filling in sections as I go, including CVs and Blog! But you're probably here for the labs, so you can check them out below! Please let me know if you find any bugs.

## Labs:

- [ENSE 374: Schedule](/labs/ense-374/)
- [ENSE 374: Lab 1](/labs/ense-374/lab-1)
- [ENSE 374: Lab 2](/labs/ense-374/lab-2)
- [ENSE 374: Lab 3](/labs/ense-374/lab-3)
- [ENSE 374: Lab 4](/labs/ense-374/lab-4)
- [ENSE 374: Lab 5](/labs/ense-374/lab-5)
- [ENSE 374: Lab 6](/labs/ense-374/lab-6)
- [ENSE 374: Lab 7](/labs/ense-374/lab-7)
- [ENSE 374: Lab 8](/labs/ense-374/lab-8)
- [ENSE 374: Lab 9](/labs/ense-374/lab-9)
- [ENSE 411: Schedule](/labs/ense-411/schedule)
- [ENSE 411: Lab 0](/labs/ense-411/lab-0)
- [ENSE 411: Lab 1](/labs/ense-411/lab-1)
- [ENSE 411: Lab 2](/labs/ense-411/lab-2)
- [ENSE 411: Lab 3](/labs/ense-411/lab-3)
- [ENSE 411: Lab 4](/labs/ense-411/lab-4)
- [ENSE 411: Lab 5](/labs/ense-411/lab-5)
- [ENSE 472: Schedule](/labs/ense-472/)
- [ENSE 472: Lab 1](/labs/ense-472/lab-1)
- [ENSE 472: Lab 2](/labs/ense-472/lab-2)
- [ENSE 472: Lab 3](/labs/ense-472/lab-3)
- [ENSE 472: Lab 4](/labs/ense-472/lab-4)
- [ENSE 472: Lab 5](/labs/ense-472/lab-5)
  
## Technologies Used in Building this Site:

- [Jekyll](https://jekyllrb.com/)
- Ruby (To write Custom Jekyll Plugins for Collapsible Sections)
- Custom Theme extended from [Cayman theme](https://rubygems.org/gems/jekyll-theme-cayman/versions/0.0.3)
- Custom CSS and JavaScript for interactions
- Hosting with [GitHub Pages](https://pages.github.com/)

## Site To Do list / Known bugs
- Mobile buttons are a bit wonky
- If you resize a window, the collapsible sections do not automatically expand to adapt